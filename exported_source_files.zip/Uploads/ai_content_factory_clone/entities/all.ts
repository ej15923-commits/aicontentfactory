
// Entity types for Content and Publishing Schedule management

export interface ContentItem {
  id: string;
  title: string;
  content: string;
  type: 'article' | 'social_post' | 'video_script' | 'email';
  status: 'draft' | 'approved' | 'published' | 'archived';
  platform?: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
  userId: string;
  projectId?: string;
  metadata?: {
    wordCount?: number;
    readingTime?: number;
    targetAudience?: string;
    tone?: string;
  };
}

export interface PublishingScheduleItem {
  id: string;
  contentId: string;
  content_id?: string; // Alternative field name for compatibility
  userId: string;
  platform: 'facebook' | 'instagram' | 'twitter' | 'linkedin' | 'tiktok' | 'youtube';
  scheduledTime: string;
  scheduled_time?: string; // Alternative field name for compatibility
  status: 'scheduled' | 'published' | 'failed' | 'cancelled';
  postContent?: string;
  hashtags?: string[];
  mediaUrls?: string[];
  createdAt: string;
  updatedAt: string;
}

// Mock API functions for Content management
export class Content {
  static async list(orderBy: string = '-createdAt'): Promise<ContentItem[]> {
    try {
      const response = await fetch('/api/content?' + new URLSearchParams({
        sort: orderBy
      }));
      if (!response.ok) throw new Error('Failed to fetch content');
      return await response.json();
    } catch (error) {
      console.error('Content.list error:', error);
      return [];
    }
  }

  static async filter(filters: any, orderBy: string = '-createdAt'): Promise<ContentItem[]> {
    try {
      const params = new URLSearchParams({
        sort: orderBy,
        ...Object.fromEntries(Object.entries(filters).map(([k, v]) => [k, String(v)]))
      });
      const response = await fetch('/api/content?' + params);
      if (!response.ok) throw new Error('Failed to fetch filtered content');
      return await response.json();
    } catch (error) {
      console.error('Content.filter error:', error);
      return [];
    }
  }

  static async get(id: string): Promise<ContentItem | null> {
    try {
      const response = await fetch(`/api/content/${id}`);
      if (!response.ok) throw new Error('Failed to fetch content');
      return await response.json();
    } catch (error) {
      console.error('Content.get error:', error);
      return null;
    }
  }

  static async create(data: Partial<ContentItem>): Promise<ContentItem> {
    const response = await fetch('/api/content', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to create content');
    return await response.json();
  }

  static async update(id: string, data: Partial<ContentItem>): Promise<ContentItem> {
    const response = await fetch(`/api/content/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update content');
    return await response.json();
  }

  static async delete(id: string): Promise<void> {
    const response = await fetch(`/api/content/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete content');
  }
}

// Mock API functions for PublishingSchedule management  
export class PublishingSchedule {
  static async list(orderBy: string = '-scheduledTime'): Promise<PublishingScheduleItem[]> {
    try {
      // For now, return mock data - replace with actual API call when backend is ready
      return [
        {
          id: '1',
          contentId: '1',
          userId: 'user1',
          platform: 'facebook',
          scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
          status: 'scheduled',
          postContent: 'Exciting news coming tomorrow!',
          hashtags: ['#news', '#exciting'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: '2', 
          contentId: '2',
          userId: 'user1',
          platform: 'instagram',
          scheduledTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          status: 'scheduled',
          postContent: 'Check out our latest content!',
          hashtags: ['#content', '#social'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }
      ];
    } catch (error) {
      console.error('PublishingSchedule.list error:', error);
      return [];
    }
  }

  static async get(id: string): Promise<PublishingScheduleItem | null> {
    try {
      // Mock implementation - replace with actual API call
      const schedules = await this.list();
      return schedules.find(s => s.id === id) || null;
    } catch (error) {
      console.error('PublishingSchedule.get error:', error);
      return null;
    }
  }

  static async create(data: Partial<PublishingScheduleItem>): Promise<PublishingScheduleItem> {
    try {
      // Mock implementation - replace with actual API call
      const newSchedule: PublishingScheduleItem = {
        id: Date.now().toString(),
        contentId: data.contentId || '',
        userId: data.userId || '',
        platform: data.platform || 'facebook',
        scheduledTime: data.scheduledTime || new Date().toISOString(),
        status: 'scheduled',
        postContent: data.postContent || '',
        hashtags: data.hashtags || [],
        mediaUrls: data.mediaUrls || [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...data
      };
      return newSchedule;
    } catch (error) {
      console.error('PublishingSchedule.create error:', error);
      throw error;
    }
  }

  static async update(id: string, data: Partial<PublishingScheduleItem>): Promise<PublishingScheduleItem> {
    try {
      // Mock implementation - replace with actual API call
      const existing = await this.get(id);
      if (!existing) throw new Error('Schedule not found');
      
      const updated = {
        ...existing,
        ...data,
        updatedAt: new Date().toISOString()
      };
      return updated;
    } catch (error) {
      console.error('PublishingSchedule.update error:', error);
      throw error;
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      // Mock implementation - replace with actual API call
      console.log('Deleting schedule:', id);
    } catch (error) {
      console.error('PublishingSchedule.delete error:', error);
      throw error;
    }
  }
}


"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowLeft,
  Search,
  Plus,
  FileText, 
  Target, 
  Zap, 
  Calendar,
  MoreVertical,
  Eye,
  Edit,
  Trash,
  Copy
} from "lucide-react";

interface Project {
  id: string;
  title: string;
  description: string | null;
  type: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  _count: { generatedContent: number };
  generatedContent: Array<{
    id: string;
    title: string;
    contentType: string;
    createdAt: Date;
    content: string;
  }>;
}

interface ProjectsClientProps {
  projects: Project[];
  userId: string;
}

export default function ProjectsClient({ projects, userId }: ProjectsClientProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'SOCIAL_POST': return <Target className="w-4 h-4" />;
      case 'BLOG_POST': return <FileText className="w-4 h-4" />;
      case 'EMAIL': return <FileText className="w-4 h-4" />;
      case 'AD_COPY': return <Zap className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      'PUBLISHED': 'bg-green-500/20 text-green-400 border-green-500/30',
      'IN_PROGRESS': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      'DRAFT': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
      'COMPLETED': 'bg-purple-500/20 text-purple-400 border-purple-500/30'
    };
    
    return statusColors[status as keyof typeof statusColors] || statusColors.DRAFT;
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const filteredProjects = projects?.filter(project => {
    const matchesSearch = project?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase() || '') ||
                         project?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase() || '');
    const matchesFilter = filterStatus === 'all' || project?.status === filterStatus.toUpperCase();
    
    return matchesSearch && matchesFilter;
  }) || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800/30 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="w-px h-6 bg-slate-600" />
            <div>
              <h1 className="text-2xl font-semibold text-white">Content Projects</h1>
              <p className="text-slate-400">Manage and organize your content</p>
            </div>
          </div>
          <Link href="/create">
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Project
            </Button>
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Filters and Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>
          
          <div className="flex space-x-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 rounded-md border border-slate-600 bg-slate-800/50 text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500/20"
            >
              <option value="all">All Status</option>
              <option value="draft">Draft</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="published">Published</option>
            </select>
          </div>
        </div>

        {/* Projects Grid */}
        {filteredProjects?.length > 0 ? (
          <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <Card key={project.id} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-all duration-300 group">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 rounded-lg bg-gradient-to-r from-purple-600/20 to-blue-600/20">
                        {getContentTypeIcon(project.type)}
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-white group-hover:text-purple-300 transition-colors">
                          {project.title}
                        </CardTitle>
                        <CardDescription className="text-slate-400 mt-1">
                          {project.description || `${project.type.replace('_', ' ').toLowerCase()} project`}
                        </CardDescription>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-white">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    {/* Project Stats */}
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-4">
                        <div className="text-slate-400">
                          <span className="font-medium text-white">{project._count?.generatedContent || 0}</span> content pieces
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs border ${getStatusBadge(project.status)}`}>
                          {project.status.toLowerCase().replace('_', ' ')}
                        </div>
                      </div>
                    </div>

                    {/* Recent Content */}
                    {project.generatedContent?.length > 0 && (
                      <div>
                        <p className="text-xs text-slate-500 mb-2">Recent Content:</p>
                        <div className="space-y-2">
                          {project.generatedContent.slice(0, 2).map((content) => (
                            <div key={content.id} className="flex items-center space-x-2 text-sm">
                              {getContentTypeIcon(content.contentType)}
                              <span className="text-slate-300 truncate flex-1">{content.title}</span>
                              <span className="text-xs text-slate-500">
                                {formatDate(content.createdAt)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Project Dates */}
                    <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-700">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>Created {formatDate(project.createdAt)}</span>
                      </div>
                      <span>Updated {formatDate(project.updatedAt)}</span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex space-x-2 pt-2">
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="flex-1 text-slate-400 hover:text-white hover:bg-slate-700/50"
                        onClick={() => {
                          // Navigate to project detail view
                          window.location.href = `/project/${project?.id}`;
                        }}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="flex-1 text-slate-400 hover:text-white hover:bg-slate-700/50"
                        onClick={() => {
                          // Navigate to create page with project context
                          window.location.href = `/create?project=${project?.id}`;
                        }}
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete "${project?.title}"?`)) {
                            // Add delete functionality here
                            console.log('Delete project:', project?.id);
                          }
                        }}
                      >
                        <Trash className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="py-16">
              <div className="text-center">
                <FileText className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                <h3 className="text-xl font-semibold text-white mb-2">
                  {searchQuery || filterStatus !== 'all' ? 'No matching projects' : 'No projects yet'}
                </h3>
                <p className="text-slate-400 max-w-md mx-auto mb-6">
                  {searchQuery || filterStatus !== 'all' 
                    ? 'Try adjusting your search or filter criteria'
                    : 'Start creating amazing content with AI-powered templates'
                  }
                </p>
                <Link href="/create">
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Project
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Trash2, Edit, Play, Pause, Plus, Zap, Clock, Target, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

interface Workflow {
  id: string;
  name: string;
  description: string;
  trigger: string;
  actions: string[];
  status: 'active' | 'inactive';
  lastRun?: string;
  createdAt: string;
}

export function WorkflowsClient() {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingWorkflow, setEditingWorkflow] = useState<Workflow | null>(null);
  const [newWorkflow, setNewWorkflow] = useState({
    name: '',
    description: '',
    trigger: '',
    actions: ['']
  });

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    try {
      const response = await fetch('/api/workflows');
      if (response.ok) {
        const data = await response.json();
        setWorkflows(data);
      }
    } catch (error) {
      console.error('Error fetching workflows:', error);
    }
  };

  const createWorkflow = async () => {
    try {
      const response = await fetch('/api/workflows', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newWorkflow),
      });

      if (response.ok) {
        const workflow = await response.json();
        setWorkflows([...workflows, workflow]);
        setNewWorkflow({ name: '', description: '', trigger: '', actions: [''] });
        setIsCreating(false);
      }
    } catch (error) {
      console.error('Error creating workflow:', error);
    }
  };

  const deleteWorkflow = async (id: string) => {
    try {
      const response = await fetch(`/api/workflows/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setWorkflows(workflows.filter(w => w.id !== id));
      }
    } catch (error) {
      console.error('Error deleting workflow:', error);
    }
  };

  const toggleWorkflowStatus = async (id: string, status: 'active' | 'inactive') => {
    try {
      const response = await fetch(`/api/workflows/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        setWorkflows(workflows.map(w => 
          w.id === id ? { ...w, status } : w
        ));
      }
    } catch (error) {
      console.error('Error updating workflow:', error);
    }
  };

  const addAction = () => {
    setNewWorkflow({
      ...newWorkflow,
      actions: [...newWorkflow.actions, '']
    });
  };

  const updateAction = (index: number, value: string) => {
    const updatedActions = [...newWorkflow.actions];
    updatedActions[index] = value;
    setNewWorkflow({
      ...newWorkflow,
      actions: updatedActions
    });
  };

  const removeAction = (index: number) => {
    setNewWorkflow({
      ...newWorkflow,
      actions: newWorkflow.actions.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto">
        {/* Back to Dashboard Button */}
        <div className="mb-6 pt-6 px-6">
          <Link href="/dashboard">
            <Button 
              variant="ghost" 
              className="text-white hover:bg-white/10 transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        <div className="flex justify-between items-center mb-8 px-6">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Workflows</h1>
            <p className="text-slate-400">Automate your content creation process</p>
          </div>
          <Button 
            onClick={() => setIsCreating(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Workflow
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 px-6">
          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Workflows</CardTitle>
              <Zap className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{workflows.length}</div>
              <p className="text-xs text-slate-400">
                {workflows.filter(w => w.status === 'active').length} active
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Workflows</CardTitle>
              <Play className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {workflows.filter(w => w.status === 'active').length}
              </div>
              <p className="text-xs text-slate-400">Running automatically</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Last 24h Runs</CardTitle>
              <Clock className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-slate-400">Workflow executions</p>
            </CardContent>
          </Card>
        </div>

        {/* Create Workflow Form */}
        {isCreating && (
          <Card className="bg-slate-800/50 border-slate-700 text-white mb-8 mx-6">
            <CardHeader>
              <CardTitle>Create New Workflow</CardTitle>
              <CardDescription className="text-slate-400">
                Set up automated content creation workflows
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Workflow Name</Label>
                  <Input
                    id="name"
                    value={newWorkflow.name}
                    onChange={(e) => setNewWorkflow({...newWorkflow, name: e.target.value})}
                    placeholder="e.g., Daily Social Media Posts"
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="trigger">Trigger</Label>
                  <Select 
                    value={newWorkflow.trigger} 
                    onValueChange={(value) => setNewWorkflow({...newWorkflow, trigger: value})}
                  >
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                      <SelectValue placeholder="Select trigger" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="schedule">Schedule</SelectItem>
                      <SelectItem value="webhook">Webhook</SelectItem>
                      <SelectItem value="manual">Manual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newWorkflow.description}
                  onChange={(e) => setNewWorkflow({...newWorkflow, description: e.target.value})}
                  placeholder="Describe what this workflow does..."
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>

              <div>
                <Label>Actions</Label>
                {newWorkflow.actions.map((action, index) => (
                  <div key={index} className="flex gap-2 mt-2">
                    <Select 
                      value={action} 
                      onValueChange={(value) => updateAction(index, value)}
                    >
                      <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                        <SelectValue placeholder="Select action" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="generate-content">Generate Content</SelectItem>
                        <SelectItem value="generate-image">Generate Image</SelectItem>
                        <SelectItem value="publish-social">Publish to Social Media</SelectItem>
                        <SelectItem value="send-email">Send Email</SelectItem>
                      </SelectContent>
                    </Select>
                    {newWorkflow.actions.length > 1 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => removeAction(index)}
                        className="bg-red-600/20 border-red-400/20 text-red-400 hover:bg-red-600/30"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={addAction}
                  className="mt-2 bg-purple-600/20 border-purple-400/20 text-purple-400 hover:bg-purple-600/30"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Action
                </Button>
              </div>

              <div className="flex gap-2">
                <Button onClick={createWorkflow} className="bg-purple-600 hover:bg-purple-700">
                  Create Workflow
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsCreating(false)}
                  className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Workflows List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-6">
          {workflows.map((workflow) => (
            <Card key={workflow.id} className="bg-slate-800/50 border-slate-700 text-white">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{workflow.name}</CardTitle>
                    <CardDescription className="text-slate-400">
                      {workflow.description}
                    </CardDescription>
                  </div>
                  <Badge 
                    variant={workflow.status === 'active' ? 'default' : 'secondary'}
                    className={workflow.status === 'active' 
                      ? 'bg-green-600/20 text-green-400 border-green-400/20' 
                      : 'bg-slate-600/20 text-slate-400 border-slate-400/20'
                    }
                  >
                    {workflow.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-slate-400">
                    <Target className="w-4 h-4 mr-2" />
                    Trigger: {workflow.trigger}
                  </div>
                  <div className="flex items-center text-sm text-slate-400">
                    <Zap className="w-4 h-4 mr-2" />
                    Actions: {workflow.actions.length}
                  </div>
                  {workflow.lastRun && (
                    <div className="flex items-center text-sm text-slate-400">
                      <Clock className="w-4 h-4 mr-2" />
                      Last run: {new Date(workflow.lastRun).toLocaleDateString()}
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleWorkflowStatus(
                      workflow.id, 
                      workflow.status === 'active' ? 'inactive' : 'active'
                    )}
                    className={workflow.status === 'active' 
                      ? 'bg-red-600/20 border-red-400/20 text-red-400 hover:bg-red-600/30' 
                      : 'bg-green-600/20 border-green-400/20 text-green-400 hover:bg-green-600/30'
                    }
                  >
                    {workflow.status === 'active' ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setEditingWorkflow(workflow)}
                    className="bg-slate-700/50 border-slate-600 text-slate-400 hover:bg-slate-600/50"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => deleteWorkflow(workflow.id)}
                    className="bg-red-600/20 border-red-400/20 text-red-400 hover:bg-red-600/30"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {workflows.length === 0 && !isCreating && (
          <Card className="bg-slate-800/50 border-slate-700 text-white text-center py-12 mx-6">
            <CardContent>
              <Zap className="w-16 h-16 mx-auto mb-4 text-purple-400" />
              <h3 className="text-xl font-semibold mb-2">No workflows yet</h3>
              <p className="text-slate-400 mb-4">
                Create your first workflow to automate your content creation process
              </p>
              <Button 
                onClick={() => setIsCreating(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Workflow
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}


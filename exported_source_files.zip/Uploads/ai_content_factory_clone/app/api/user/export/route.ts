
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Fetch all user data
    const [user, projects, content, automations] = await Promise.all([
      prisma.user.findUnique({
        where: { id: session.user.id }
      }),
      prisma.contentProject.findMany({
        where: { userId: session.user.id }
      }),
      prisma.generatedContent.findMany({
        where: { userId: session.user.id }
      }),
      prisma.automationConfig.findMany({
        where: { userId: session.user.id }
      })
    ]);

    const exportData = {
      user,
      projects,
      content,
      automations,
      exportDate: new Date().toISOString()
    };

    return new Response(JSON.stringify(exportData, null, 2), {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': 'attachment; filename="ai-content-factory-export.json"'
      }
    });

  } catch (error) {
    console.error("Data export error:", error);
    return NextResponse.json(
      { error: "Failed to export data" },
      { status: 500 }
    );
  }
}

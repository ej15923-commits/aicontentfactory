
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { 
      title, 
      content, 
      contentType, 
      templateId, 
      projectId, 
      generationData 
    } = await req.json();

    if (!title || !content) {
      return NextResponse.json(
        { error: "Title and content are required" }, 
        { status: 400 }
      );
    }

    // Create or find project
    let project;
    if (projectId) {
      project = await prisma.contentProject.findFirst({
        where: { id: projectId, userId: session.user.id }
      });
      if (!project) {
        return NextResponse.json(
          { error: "Project not found" }, 
          { status: 404 }
        );
      }
    } else {
      // Create new project
      project = await prisma.contentProject.create({
        data: {
          title,
          type: contentType || 'TEXT',
          userId: session.user.id,
          status: 'DRAFT'
        }
      });
    }

    // Save generated content
    const generatedContent = await prisma.generatedContent.create({
      data: {
        title,
        content,
        contentType: contentType || 'TEXT',
        projectId: project.id,
        userId: session.user.id,
        templateId: templateId || null,
        generationData: generationData || {}
      }
    });

    // Update project timestamp
    await prisma.contentProject.update({
      where: { id: project.id },
      data: { updatedAt: new Date() }
    });

    return NextResponse.json({ 
      success: true,
      contentId: generatedContent.id,
      projectId: project.id
    });

  } catch (error) {
    console.error("Save content error:", error);
    return NextResponse.json(
      { error: "Failed to save content" },
      { status: 500 }
    );
  }
}

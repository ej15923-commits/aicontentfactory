

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { url, automationId, affiliateLink } = await req.json();

    // Get automation configuration
    const automation = await prisma.automationConfig.findFirst({
      where: { 
        id: automationId,
        userId: session.user.id,
        isActive: true 
      }
    });

    if (!automation) {
      return NextResponse.json({ error: "Automation not found or inactive" }, { status: 404 });
    }

    // Step 1: Scrape URL content
    console.log(`Starting full automation process for URL: ${url}`);
    const scrapedContent = await scrapeUrlContent(url);
    
    if (!scrapedContent) {
      throw new Error("Failed to scrape content from URL");
    }

    // Step 2: Generate content for each enabled content type
    const contentTypes = automation.contentTypes as any;
    const generatedContent = [];

    for (const [type, enabled] of Object.entries(contentTypes)) {
      if (enabled) {
        const content = await generateContentFromScrape({
          scrapedContent,
          contentType: type,
          niche: automation.niche,
          targetAudience: automation.targetAudience,
          brandVoice: automation.brandVoice,
          affiliateLink: affiliateLink || automation.affiliateLink
        });

        if (content) {
          // Step 3: Auto-save content (no manual review)
          const savedContent = await autoSaveContent({
            content,
            contentType: type,
            userId: session.user.id,
            sourceUrl: url,
            automationId: automation.id
          });

          // Step 4: Auto-approve and schedule for publishing
          const scheduledContent = await autoScheduleContent({
            contentId: savedContent.id,
            contentType: type,
            userId: session.user.id,
            frequency: automation.frequency
          });

          generatedContent.push({
            type,
            contentId: savedContent.id,
            publishSchedule: scheduledContent.scheduledTime
          });
        }
      }
    }

    // Step 5: Auto-publish immediately if configured for immediate publishing
    for (const content of generatedContent) {
      await autoPublishContent({
        contentId: content.contentId,
        userId: session.user.id,
        platforms: await getConnectedPlatforms(session.user.id)
      });
    }

    // Update automation last run
    await prisma.automationConfig.update({
      where: { id: automation.id },
      data: { 
        lastRun: new Date(),
        nextRun: calculateNextRun(automation.frequency)
      }
    });

    return NextResponse.json({ 
      success: true,
      processedUrl: url,
      generatedContent,
      message: `Fully automated process completed: ${generatedContent.length} pieces of content generated and auto-published`
    });

  } catch (error) {
    console.error("Full automation process error:", error);
    return NextResponse.json(
      { error: "Failed to complete automation process" },
      { status: 500 }
    );
  }
}

// Helper function to scrape URL content
async function scrapeUrlContent(url: string) {
  try {
    const response = await fetch(url);
    const html = await response.text();
    
    // Basic content extraction - you can enhance this with proper scraping libraries
    const titleMatch = html.match(/<title>(.*?)<\/title>/i);
    const metaDescMatch = html.match(/<meta\s+name="description"\s+content="(.*?)"/i);
    
    // Extract main content (simplified - you may want to use libraries like cheerio for better extraction)
    const textContent = html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    return {
      url,
      title: titleMatch ? titleMatch[1] : '',
      description: metaDescMatch ? metaDescMatch[1] : '',
      content: textContent.substring(0, 2000), // Limit content length
      scrapedAt: new Date()
    };
  } catch (error) {
    console.error('Failed to scrape URL:', error);
    return null;
  }
}

// Helper function to generate content from scraped data
async function generateContentFromScrape({
  scrapedContent,
  contentType,
  niche,
  targetAudience,
  brandVoice,
  affiliateLink
}: {
  scrapedContent: any;
  contentType: string;
  niche: string;
  targetAudience: string;
  brandVoice: string;
  affiliateLink?: string;
}) {
  try {
    const prompt = createPromptFromScrape({
      scrapedContent,
      contentType,
      niche,
      targetAudience,
      brandVoice,
      affiliateLink
    });

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are an expert content creator specializing in ${contentType.toLowerCase().replace('_', ' ')}. Create high-quality, engaging content based on the scraped information provided. Adapt the content for ${targetAudience} with a ${brandVoice} tone in the ${niche} niche.`
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 2000,
        temperature: 0.7
      }),
    });

    if (!response.ok) {
      throw new Error(`AI API request failed: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Failed to generate content:', error);
    return null;
  }
}

// Helper function to create prompt from scraped content
function createPromptFromScrape({
  scrapedContent,
  contentType,
  niche,
  targetAudience,
  brandVoice,
  affiliateLink
}: {
  scrapedContent: any;
  contentType: string;
  niche: string;
  targetAudience: string;
  brandVoice: string;
  affiliateLink?: string;
}) {
  const basePrompt = `Based on the following scraped content, create engaging ${contentType} content:

Source URL: ${scrapedContent.url}
Title: ${scrapedContent.title}
Description: ${scrapedContent.description}
Content Preview: ${scrapedContent.content}

Requirements:
- Target Audience: ${targetAudience}
- Brand Voice: ${brandVoice}
- Niche: ${niche}
- Content Type: ${contentType}
${affiliateLink ? `- Affiliate Link Integration: Contextually embed this link "${affiliateLink}" in the content where appropriate (as "Learn more", "Get started", "Check it out", or similar natural call-to-action)` : ''}
`;

  switch (contentType) {
    case 'socialPosts':
      return `${basePrompt}
- Create 3 social media posts with different angles/perspectives
- Keep each post under 280 characters for Twitter compatibility
- Include relevant hashtags
- Make them shareable and engaging
${affiliateLink ? '- If including the affiliate link, make it feel natural and valuable (e.g., "Learn more: [link]", "Check this out: [link]")' : ''}`;
    
    case 'blogPosts':
      return `${basePrompt}
- Create a comprehensive blog post (800-1200 words)
- Include an engaging headline and meta description
- Structure with clear headings and subheadings
- Add a compelling introduction and conclusion
- Include actionable insights
${affiliateLink ? '- Integrate the affiliate link naturally in the content flow, perhaps as a "recommended resource" or in a call-to-action section' : ''}`;
    
    case 'emails':
      return `${basePrompt}
- Create an email newsletter content
- Include subject line, preview text
- Structure with clear sections
- Add a call-to-action
- Keep it scannable and engaging
${affiliateLink ? '- Include the affiliate link as a prominent call-to-action button or "Learn more" section' : ''}`;
    
    case 'adCopy':
      return `${basePrompt}
- Create ad copy variations (3-5 different versions)
- Include headlines, descriptions, and CTAs
- Focus on conversion-oriented language
- Make them platform-agnostic
${affiliateLink ? '- Use the affiliate link as the primary call-to-action destination for all ad variations' : ''}`;
    
    default:
      return basePrompt;
  }
}

// Helper function to auto-save content
async function autoSaveContent({
  content,
  contentType,
  userId,
  sourceUrl,
  automationId
}: {
  content: string;
  contentType: string;
  userId: string;
  sourceUrl: string;
  automationId: string;
}) {
  // Create project automatically
  const project = await prisma.contentProject.create({
    data: {
      title: `Auto-generated from ${new URL(sourceUrl).hostname}`,
      type: mapContentTypeToEnum(contentType),
      userId,
      status: 'COMPLETED' // Auto-approve
    }
  });

  // Save generated content
  const generatedContent = await prisma.generatedContent.create({
    data: {
      title: extractTitleFromContent(content, contentType),
      content,
      contentType: mapContentTypeToEnum(contentType),
      projectId: project.id,
      userId,
      generationData: {
        sourceUrl,
        automationId,
        autoGenerated: true,
        generatedAt: new Date().toISOString()
      }
    }
  });

  return generatedContent;
}

// Helper function to auto-schedule content
async function autoScheduleContent({
  contentId,
  contentType,
  userId,
  frequency
}: {
  contentId: string;
  contentType: string;
  userId: string;
  frequency: string;
}) {
  const scheduledTime = calculateScheduleTime(frequency);
  const platforms = await getConnectedPlatforms(userId);
  
  const publishedContent = await prisma.publishedContent.create({
    data: {
      contentId,
      userId,
      platform: platforms.join(','), // Store multiple platforms
      title: `Auto-generated ${contentType}`,
      content: await getContentById(contentId),
      scheduledTime,
      status: 'SCHEDULED'
    }
  });

  return publishedContent;
}

// Helper function to auto-publish content
async function autoPublishContent({
  contentId,
  userId,
  platforms
}: {
  contentId: string;
  userId: string;
  platforms: string[];
}) {
  for (const platform of platforms) {
    try {
      // Simulate publishing to platform (replace with actual platform APIs)
      const publishResult = await publishToPlatform(platform, contentId);
      
      // Update published content status
      await prisma.publishedContent.updateMany({
        where: { 
          contentId,
          userId,
          platform: { contains: platform }
        },
        data: { 
          status: 'PUBLISHED',
          publishedTime: new Date(),
          platformPostId: publishResult.postId
        }
      });
    } catch (error) {
      console.error(`Failed to publish to ${platform}:`, error);
      
      await prisma.publishedContent.updateMany({
        where: { 
          contentId,
          userId,
          platform: { contains: platform }
        },
        data: { 
          status: 'FAILED'
        }
      });
    }
  }
}

// Helper functions
function mapContentTypeToEnum(contentType: string) {
  const mapping: Record<string, string> = {
    'socialPosts': 'SOCIAL_POST',
    'blogPosts': 'BLOG_POST',
    'emails': 'EMAIL',
    'adCopy': 'AD_COPY'
  };
  return (mapping[contentType] || 'TEXT') as any;
}

function extractTitleFromContent(content: string, contentType: string): string {
  // Extract first line or create title based on content type
  const firstLine = content.split('\n')[0];
  if (firstLine.length > 5 && firstLine.length < 100) {
    return firstLine.replace(/^#+\s*/, ''); // Remove markdown headers
  }
  return `Auto-generated ${contentType} - ${new Date().toLocaleDateString()}`;
}

function calculateScheduleTime(frequency: string): Date {
  const now = new Date();
  switch (frequency) {
    case 'hourly':
      return new Date(now.getTime() + 60 * 60 * 1000); // 1 hour
    case 'daily':
      return new Date(now.getTime() + 24 * 60 * 60 * 1000); // 1 day
    case 'weekly':
      return new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000); // 1 week
    case 'monthly':
      return new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days
    default:
      return new Date(now.getTime() + 60 * 60 * 1000); // Default 1 hour
  }
}

function calculateNextRun(frequency: string): Date {
  return calculateScheduleTime(frequency);
}

async function getConnectedPlatforms(userId: string): Promise<string[]> {
  // For now, return mock connected platforms
  // In a real implementation, you'd check user's connected social media accounts
  return ['twitter', 'facebook', 'linkedin'];
}

async function getContentById(contentId: string): Promise<string> {
  const content = await prisma.generatedContent.findUnique({
    where: { id: contentId }
  });
  return content?.content || '';
}

async function publishToPlatform(platform: string, contentId: string): Promise<{ postId: string }> {
  // Mock publishing - replace with actual platform APIs
  console.log(`Publishing content ${contentId} to ${platform}`);
  return { postId: `${platform}_${Date.now()}` };
}


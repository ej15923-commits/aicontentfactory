
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { config } = await req.json();

    // Create automation configuration in database
    const automation = await prisma.automationConfig.create({
      data: {
        userId: session.user.id,
        contentTypes: config.contentTypes,
        frequency: config.frequency,
        niche: config.niche,
        targetAudience: config.targetAudience,
        brandVoice: config.brandVoice,
        affiliateLink: config.affiliateLink || null,
        isActive: true
      }
    });

    // Here you would typically start a background job/cron job
    // For now, we'll just return success
    console.log('Automation started for user:', session.user.id, 'with config:', config);

    return NextResponse.json({ 
      success: true, 
      automationId: automation.id,
      message: "Automation started successfully" 
    });

  } catch (error) {
    console.error("Automation start error:", error);
    return NextResponse.json(
      { error: "Failed to start automation" },
      { status: 500 }
    );
  }
}

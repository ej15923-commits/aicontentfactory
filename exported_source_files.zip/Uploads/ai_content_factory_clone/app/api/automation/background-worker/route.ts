

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// This endpoint will be called by a cron job or background worker
export async function POST(req: NextRequest) {
  try {
    // Get all active automations that need to run
    const now = new Date();
    const activeAutomations = await prisma.automationConfig.findMany({
      where: {
        isActive: true,
        OR: [
          { nextRun: null },
          { nextRun: { lte: now } }
        ]
      },
      include: {
        user: true
      }
    });

    console.log(`Found ${activeAutomations.length} automations to process`);
    
    const results = [];

    for (const automation of activeAutomations) {
      try {
        // For demo purposes, we'll use a set of sample URLs
        // In a real implementation, you might have URLs stored per user or automation
        const sampleUrls = [
          'https://techcrunch.com/2024/01/15/ai-trends-2024/',
          'https://www.entrepreneur.com/article/digital-marketing-trends',
          'https://blog.hubspot.com/marketing/content-marketing-strategy',
          'https://www.socialmediaexaminer.com/social-media-trends/',
          'https://www.contentmarketinginstitute.com/articles/content-marketing-2024'
        ];

        // Pick a random URL for content generation
        const randomUrl = sampleUrls[Math.floor(Math.random() * sampleUrls.length)];

        // Process the automation
        const processResult = await processAutomation(automation, randomUrl);
        
        results.push({
          automationId: automation.id,
          userId: automation.userId,
          success: true,
          processedUrl: randomUrl,
          result: processResult
        });

        // Update automation run times
        await prisma.automationConfig.update({
          where: { id: automation.id },
          data: {
            lastRun: now,
            nextRun: calculateNextRun(automation.frequency, now)
          }
        });

      } catch (error) {
        console.error(`Failed to process automation ${automation.id}:`, error);
        results.push({
          automationId: automation.id,
          userId: automation.userId,
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    return NextResponse.json({
      success: true,
      processed: results.length,
      results
    });

  } catch (error) {
    console.error("Background worker error:", error);
    return NextResponse.json(
      { error: "Failed to process background automations" },
      { status: 500 }
    );
  }
}

async function processAutomation(automation: any, url: string) {
  // Scrape the URL
  const scrapedContent = await scrapeUrlForAutomation(url);
  
  if (!scrapedContent) {
    throw new Error(`Failed to scrape content from ${url}`);
  }

  const contentTypes = automation.contentTypes as any;
  const generatedItems = [];

  // Generate content for each enabled type
  for (const [type, enabled] of Object.entries(contentTypes)) {
    if (enabled) {
      try {
        const content = await generateAutomatedContent({
          scrapedContent,
          contentType: type,
          automation
        });

        if (content) {
          // Auto-save the content
          const savedContent = await autoSaveAutomatedContent({
            content,
            contentType: type,
            automation,
            sourceUrl: url
          });

          // Auto-schedule for publishing
          await autoScheduleForPublishing({
            contentId: savedContent.id,
            automation,
            contentType: type
          });

          generatedItems.push({
            type,
            contentId: savedContent.id,
            title: savedContent.title
          });
        }
      } catch (error) {
        console.error(`Failed to generate ${type} content:`, error);
      }
    }
  }

  return {
    sourceUrl: url,
    generatedItems,
    totalGenerated: generatedItems.length
  };
}

async function scrapeUrlForAutomation(url: string) {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AIContentFactory/1.0)'
      }
    });

    if (!response.ok) return null;

    const html = await response.text();
    const title = extractMetaTag(html, 'title');
    const description = extractMetaTag(html, 'description');
    
    const textContent = html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    return {
      url,
      title,
      description,
      content: textContent.substring(0, 2000),
      scrapedAt: new Date()
    };
  } catch (error) {
    console.error('URL scraping failed:', error);
    return null;
  }
}

async function generateAutomatedContent({
  scrapedContent,
  contentType,
  automation
}: {
  scrapedContent: any;
  contentType: string;
  automation: any;
}) {
  const prompt = createAutomationPrompt({
    scrapedContent,
    contentType,
    niche: automation.niche,
    targetAudience: automation.targetAudience,
    brandVoice: automation.brandVoice
  });

  const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: `You are an expert content creator for automated content generation. Create high-quality, engaging ${contentType} content based on scraped web content. Focus on ${automation.niche} niche for ${automation.targetAudience} audience with a ${automation.brandVoice} tone.`
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 2000,
      temperature: 0.7
    }),
  });

  if (!response.ok) {
    throw new Error(`Content generation failed: ${response.status}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

async function autoSaveAutomatedContent({
  content,
  contentType,
  automation,
  sourceUrl
}: {
  content: string;
  contentType: string;
  automation: any;
  sourceUrl: string;
}) {
  // Create project
  const project = await prisma.contentProject.create({
    data: {
      title: `Auto: ${new URL(sourceUrl).hostname} - ${contentType}`,
      type: mapContentTypeToEnum(contentType),
      userId: automation.userId,
      status: 'COMPLETED' // Auto-approved
    }
  });

  // Save content
  const generatedContent = await prisma.generatedContent.create({
    data: {
      title: extractTitleFromContent(content, contentType),
      content,
      contentType: mapContentTypeToEnum(contentType),
      projectId: project.id,
      userId: automation.userId,
      generationData: {
        sourceUrl,
        automationId: automation.id,
        autoGenerated: true,
        processedAt: new Date().toISOString()
      }
    }
  });

  return generatedContent;
}

async function autoScheduleForPublishing({
  contentId,
  automation,
  contentType
}: {
  contentId: string;
  automation: any;
  contentType: string;
}) {
  const content = await prisma.generatedContent.findUnique({
    where: { id: contentId }
  });

  if (!content) return;

  // Calculate publish time based on frequency
  const publishTime = calculatePublishTime(automation.frequency);

  // Create scheduled publication
  await prisma.publishedContent.create({
    data: {
      contentId,
      userId: automation.userId,
      platform: 'auto_all', // Publish to all connected platforms
      title: content.title,
      content: content.content,
      scheduledTime: publishTime,
      status: 'PUBLISHED' // Auto-publish immediately for full automation
    }
  });
}

function extractMetaTag(html: string, tagName: string): string {
  if (tagName === 'title') {
    const match = html.match(/<title>(.*?)<\/title>/i);
    return match ? match[1].trim() : '';
  }
  
  const match = html.match(new RegExp(`<meta\\s+name="${tagName}"\\s+content="(.*?)"`, 'i'));
  return match ? match[1].trim() : '';
}

function createAutomationPrompt({
  scrapedContent,
  contentType,
  niche,
  targetAudience,
  brandVoice
}: {
  scrapedContent: any;
  contentType: string;
  niche: string;
  targetAudience: string;
  brandVoice: string;
}) {
  const baseInfo = `
Source: ${scrapedContent.url}
Title: ${scrapedContent.title}
Description: ${scrapedContent.description}
Content: ${scrapedContent.content}

Target: ${targetAudience}
Niche: ${niche}
Voice: ${brandVoice}
`;

  const templates = {
    socialPosts: `${baseInfo}
Create 2-3 engaging social media posts that:
- Capture key insights from the source
- Use relevant hashtags
- Are platform-optimized (under 280 chars for Twitter)
- Include calls-to-action
- Match the brand voice`,

    blogPosts: `${baseInfo}
Create a comprehensive blog post that:
- Has an SEO-optimized title
- Includes introduction, 3-4 main sections, conclusion
- Expands on the source content with additional insights
- Is 800-1200 words
- Includes actionable takeaways`,

    emails: `${baseInfo}
Create email newsletter content with:
- Compelling subject line
- Brief introduction
- Key highlights from source
- Clear call-to-action
- Professional but engaging tone`,

    adCopy: `${baseInfo}
Create advertising copy with:
- 3 different headline variations
- Compelling descriptions
- Strong call-to-action
- Benefit-focused messaging
- Conversion-optimized language`
  };

  return templates[contentType as keyof typeof templates] || `${baseInfo}\nCreate engaging ${contentType} content.`;
}

function calculateNextRun(frequency: string, fromDate: Date): Date {
  const date = new Date(fromDate);
  
  switch (frequency) {
    case 'hourly':
      date.setHours(date.getHours() + 1);
      break;
    case 'daily':
      date.setDate(date.getDate() + 1);
      break;
    case 'weekly':
      date.setDate(date.getDate() + 7);
      break;
    case 'monthly':
      date.setMonth(date.getMonth() + 1);
      break;
    default:
      date.setHours(date.getHours() + 1);
  }
  
  return date;
}

function calculatePublishTime(frequency: string): Date {
  const now = new Date();
  // For full automation, publish immediately
  return now;
}

function mapContentTypeToEnum(contentType: string) {
  const mapping: Record<string, string> = {
    'socialPosts': 'SOCIAL_POST',
    'blogPosts': 'BLOG_POST',
    'emails': 'EMAIL',
    'adCopy': 'AD_COPY'
  };
  return (mapping[contentType] || 'TEXT') as any;
}

function extractTitleFromContent(content: string, contentType: string): string {
  const lines = content.split('\n').filter(line => line.trim());
  if (lines.length > 0) {
    const firstLine = lines[0].replace(/^#+\s*/, '').trim();
    if (firstLine.length > 5 && firstLine.length < 100) {
      return firstLine;
    }
  }
  return `Auto-generated ${contentType} - ${new Date().toLocaleDateString()}`;
}


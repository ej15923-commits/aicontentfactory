
"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowLeft,
  Sparkles, 
  FileText, 
  Target, 
  Zap, 
  Settings, 
  Copy,
  Download,
  Share,
  Save,
  Plus,
  Wand2,
  Loader2
} from "lucide-react";

interface Template {
  id: string;
  name: string;
  description: string | null;
  category: string;
  contentType: string;
  prompt: string;
  variables: any;
}

interface Project {
  id: string;
  title: string;
  type: string;
}

interface CreateContentClientProps {
  userId: string;
  templates: Template[];
  projects: Project[];
}

export default function CreateContentClient({ 
  userId, 
  templates, 
  projects 
}: CreateContentClientProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState("");
  const [error, setError] = useState("");
  const [projectTitle, setProjectTitle] = useState("");
  const [selectedProject, setSelectedProject] = useState("");
  
  const router = useRouter();
  const searchParams = useSearchParams();
  const contentType = searchParams?.get('type');

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'SOCIAL_POST': return <Target className="w-5 h-5" />;
      case 'BLOG_POST': return <FileText className="w-5 h-5" />;
      case 'EMAIL': return <FileText className="w-5 h-5" />;
      case 'AD_COPY': return <Zap className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  const getContentTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'SOCIAL_POST': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'BLOG_POST': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'EMAIL': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'AD_COPY': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  const filteredTemplates = contentType 
    ? templates.filter(t => t.contentType.toLowerCase() === contentType.replace('-', '_'))
    : templates;

  const handleTemplateSelect = (template: Template) => {
    setSelectedTemplate(template);
    setFormData({});
    setGeneratedContent("");
    setError("");
  };

  const handleInputChange = (key: string, value: string) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const generateContent = async () => {
    if (!selectedTemplate) return;
    
    setIsGenerating(true);
    setError("");
    setGeneratedContent("");

    try {
      // Create prompt with filled variables
      let prompt = selectedTemplate.prompt;
      Object.entries(formData).forEach(([key, value]) => {
        prompt = prompt.replace(new RegExp(`{${key}}`, 'g'), value || `[${key}]`);
      });

      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt,
          contentType: selectedTemplate.contentType,
          templateId: selectedTemplate.id
        }),
      });

      if (!response.body) {
        throw new Error('No response body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let partialRead = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        partialRead += decoder.decode(value, { stream: true });
        let lines = partialRead.split('\n');
        partialRead = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              return;
            }
            try {
              const parsed = JSON.parse(data);
              if (parsed.choices?.[0]?.delta?.content) {
                buffer += parsed.choices[0].delta.content;
                setGeneratedContent(buffer);
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Content generation error:', error);
      setError('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const saveContent = async () => {
    if (!generatedContent.trim() || !projectTitle.trim()) {
      setError('Please provide both content and project title');
      return;
    }

    try {
      const response = await fetch('/api/save-content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: projectTitle,
          content: generatedContent,
          contentType: selectedTemplate?.contentType || 'TEXT',
          templateId: selectedTemplate?.id,
          projectId: selectedProject || undefined,
          generationData: {
            templateName: selectedTemplate?.name,
            variables: formData
          }
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to save content');
      }

      const data = await response.json();
      router.push(`/projects`);
    } catch (error) {
      console.error('Save content error:', error);
      setError('Failed to save content. Please try again.');
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedContent);
      // Could add a toast notification here
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800/30 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="w-px h-6 bg-slate-600" />
            <div>
              <h1 className="text-2xl font-semibold text-white">Create Content</h1>
              <p className="text-slate-400">Generate AI-powered content using templates</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Template Selection */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800/50 border-slate-700 h-fit">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Target className="w-5 h-5 mr-2 text-purple-400" />
                  Select Template
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Choose a template to get started
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {filteredTemplates?.map((template) => (
                    <div
                      key={template.id}
                      onClick={() => handleTemplateSelect(template)}
                      className={`p-4 rounded-lg border cursor-pointer transition-all ${
                        selectedTemplate?.id === template.id
                          ? 'bg-purple-600/20 border-purple-500/50'
                          : 'bg-slate-700/30 border-slate-600 hover:bg-slate-700/50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {getContentTypeIcon(template.contentType)}
                          <p className="font-medium text-white">{template.name}</p>
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs border ${getContentTypeBadgeColor(template.contentType)}`}>
                          {template.contentType.replace('_', ' ')}
                        </div>
                      </div>
                      <p className="text-sm text-slate-400 mb-2">{template.description}</p>
                      <p className="text-xs text-slate-500">{template.category}</p>
                    </div>
                  )) || (
                    <div className="text-center py-8">
                      <p className="text-slate-400">No templates available</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Content Generation */}
          <div className="lg:col-span-2 space-y-6">
            {selectedTemplate ? (
              <>
                {/* Template Variables Form */}
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Settings className="w-5 h-5 mr-2 text-blue-400" />
                      Configure Template
                    </CardTitle>
                    <CardDescription className="text-slate-400">
                      Fill in the variables for {selectedTemplate.name}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {selectedTemplate.variables && typeof selectedTemplate.variables === 'object' ? (
                        Object.entries(selectedTemplate.variables).map(([key, type]) => (
                          <div key={key}>
                            <label className="block text-sm font-medium text-slate-300 mb-2">
                              {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
                              <span className="text-slate-500 ml-1">({type as string})</span>
                            </label>
                            <Input
                              placeholder={`Enter ${key}...`}
                              value={formData[key] || ''}
                              onChange={(e) => handleInputChange(key, e.target.value)}
                              className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-purple-500 focus:ring-purple-500/20"
                            />
                          </div>
                        ))
                      ) : (
                        <p className="text-slate-400 text-sm">No variables required for this template</p>
                      )}

                      <Button
                        onClick={generateContent}
                        disabled={isGenerating}
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium py-3 transition-all duration-200"
                      >
                        {isGenerating ? (
                          <div className="flex items-center space-x-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Generating Content...</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-2">
                            <Wand2 className="w-4 h-4" />
                            <span>Generate Content</span>
                          </div>
                        )}
                      </Button>

                      {error && (
                        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                          {error}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Generated Content */}
                {(generatedContent || isGenerating) && (
                  <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-white flex items-center">
                            <FileText className="w-5 h-5 mr-2 text-green-400" />
                            Generated Content
                          </CardTitle>
                          <CardDescription className="text-slate-400">
                            Your AI-generated content is ready
                          </CardDescription>
                        </div>
                        {generatedContent && (
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={copyToClipboard}
                              className="text-slate-400 hover:text-white"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-slate-400 hover:text-white"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-slate-400 hover:text-white"
                            >
                              <Share className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="bg-slate-700/30 rounded-lg p-4 min-h-[200px]">
                          {isGenerating ? (
                            <div className="flex items-center justify-center h-32">
                              <div className="text-center">
                                <Loader2 className="w-8 h-8 animate-spin text-purple-400 mx-auto mb-2" />
                                <p className="text-slate-400">AI is crafting your content...</p>
                              </div>
                            </div>
                          ) : (
                            <div className="prose prose-invert max-w-none">
                              <div className="whitespace-pre-wrap text-slate-200 leading-relaxed">
                                {generatedContent}
                              </div>
                            </div>
                          )}
                        </div>

                        {generatedContent && (
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-slate-300 mb-2">
                                Project Title
                              </label>
                              <Input
                                placeholder="Enter project title..."
                                value={projectTitle}
                                onChange={(e) => setProjectTitle(e.target.value)}
                                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-purple-500 focus:ring-purple-500/20"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-slate-300 mb-2">
                                Add to Project (Optional)
                              </label>
                              <select
                                value={selectedProject}
                                onChange={(e) => setSelectedProject(e.target.value)}
                                className="w-full h-9 rounded-md border border-slate-600 bg-slate-700/50 px-3 py-1 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500/20"
                              >
                                <option value="">New Project</option>
                                {projects?.map((project) => (
                                  <option key={project.id} value={project.id}>
                                    {project.title}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                        )}

                        {generatedContent && (
                          <Button
                            onClick={saveContent}
                            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-medium py-3 transition-all duration-200"
                          >
                            <Save className="w-4 h-4 mr-2" />
                            Save Content
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="py-16">
                  <div className="text-center">
                    <Target className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                    <h3 className="text-xl font-semibold text-white mb-2">Select a Template</h3>
                    <p className="text-slate-400 max-w-md mx-auto">
                      Choose a template from the left sidebar to start generating AI-powered content
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

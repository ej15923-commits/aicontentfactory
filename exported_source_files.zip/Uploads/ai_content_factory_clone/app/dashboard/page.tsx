
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import DashboardClient from "./dashboard-client";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect("/auth/signin");
  }

  // Fetch user data and projects
  const [user, projects, recentContent, templates] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, name: true, email: true, companyName: true, createdAt: true }
    }),
    prisma.contentProject.findMany({
      where: { userId: session.user.id },
      include: { _count: { select: { generatedContent: true } } },
      orderBy: { updatedAt: 'desc' },
      take: 6
    }),
    prisma.generatedContent.findMany({
      where: { userId: session.user.id },
      include: { project: true },
      orderBy: { createdAt: 'desc' },
      take: 5
    }),
    prisma.template.findMany({
      where: { isPublic: true },
      orderBy: { name: 'asc' },
      take: 8
    })
  ]);

  // Calculate stats
  const totalProjects = await prisma.contentProject.count({
    where: { userId: session.user.id }
  });
  
  const totalContent = await prisma.generatedContent.count({
    where: { userId: session.user.id }
  });

  const publishedContent = await prisma.contentProject.count({
    where: { 
      userId: session.user.id,
      status: 'PUBLISHED'
    }
  });

  if (!user) {
    redirect("/auth/signin");
  }

  return (
    <DashboardClient
      user={user}
      projects={projects || []}
      recentContent={recentContent || []}
      templates={templates || []}
      stats={{
        totalProjects,
        totalContent,
        publishedContent
      }}
    />
  );
}

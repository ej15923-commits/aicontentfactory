
"use client";

import React from "react";
import { PublishingScheduleItem, ContentItem } from "@/entities/all";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, 
  Edit3, 
  Trash2, 
  Play, 
  Pause, 
  Calendar,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Music,
  Youtube
} from "lucide-react";
import { format } from "date-fns";

interface PublishingQueueProps {
  schedules: PublishingScheduleItem[];
  content: ContentItem[];
  filters: {
    query: string;
    platform: string;
    status: string;
    sort: string;
  };
  loading: boolean;
  onStatusChange: (scheduleId: string, newStatus: string) => void;
  onDelete: (scheduleId: string) => void;
  onEdit: (schedule: PublishingScheduleItem) => void;
}

const platformIcons = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  tiktok: Music,
  youtube: Youtube,
};

const statusColors = {
  scheduled: "bg-blue-900/20 text-blue-400 border-blue-600",
  published: "bg-green-900/20 text-green-400 border-green-600", 
  failed: "bg-red-900/20 text-red-400 border-red-600",
  cancelled: "bg-slate-700/20 text-slate-400 border-slate-600",
};

export default function PublishingQueue({
  schedules,
  content,
  filters,
  loading,
  onStatusChange,
  onDelete,
  onEdit
}: PublishingQueueProps) {
  const getFilteredSchedules = () => {
    let filtered = schedules;

    // Filter by search query
    if (filters.query) {
      filtered = filtered.filter(schedule => 
        schedule.postContent?.toLowerCase().includes(filters.query.toLowerCase()) ||
        schedule.platform.toLowerCase().includes(filters.query.toLowerCase()) ||
        schedule.hashtags?.some(tag => tag.toLowerCase().includes(filters.query.toLowerCase()))
      );
    }

    // Filter by platform
    if (filters.platform && filters.platform !== 'all') {
      filtered = filtered.filter(schedule => schedule.platform === filters.platform);
    }

    // Filter by status
    if (filters.status && filters.status !== 'all') {
      filtered = filtered.filter(schedule => schedule.status === filters.status);
    }

    // Sort
    filtered.sort((a, b) => {
      const field = filters.sort.startsWith('-') ? filters.sort.slice(1) : filters.sort;
      const direction = filters.sort.startsWith('-') ? -1 : 1;
      
      if (field === 'scheduled_time' || field === 'scheduledTime') {
        return direction * (new Date(a.scheduledTime || a.scheduled_time || '').getTime() - 
                          new Date(b.scheduledTime || b.scheduled_time || '').getTime());
      }
      
      return direction * (String(a[field as keyof PublishingScheduleItem]).localeCompare(
        String(b[field as keyof PublishingScheduleItem])
      ));
    });

    return filtered;
  };

  const getContentForSchedule = (schedule: PublishingScheduleItem): ContentItem | undefined => {
    return content.find(c => c.id === schedule.contentId || c.id === schedule.content_id);
  };

  const getTimeUntilPublication = (scheduledTime: string): string => {
    const now = new Date();
    const scheduled = new Date(scheduledTime);
    const diffMs = scheduled.getTime() - now.getTime();
    
    if (diffMs < 0) return "Overdue";
    
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) return `${diffDays}d ${diffHours % 24}h`;
    if (diffHours > 0) return `${diffHours}h`;
    
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    return `${diffMinutes}m`;
  };

  if (loading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-slate-400">Loading publishing queue...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const filteredSchedules = getFilteredSchedules();

  return (
    <div className="space-y-4">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Clock className="w-5 h-5" />
            Publishing Queue
          </CardTitle>
          <CardDescription className="text-slate-400">
            Manage your scheduled posts and publishing pipeline
          </CardDescription>
        </CardHeader>
      </Card>

      {filteredSchedules.length === 0 ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-8 text-center">
            <Clock className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">No scheduled posts</h3>
            <p className="text-slate-400">
              {filters.query || filters.platform !== 'all' || filters.status !== 'all' 
                ? "No posts match your current filters" 
                : "Schedule your first post to get started"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredSchedules.map((schedule) => {
            const scheduleContent = getContentForSchedule(schedule);
            const PlatformIcon = platformIcons[schedule.platform];
            const scheduledTime = schedule.scheduledTime || schedule.scheduled_time || '';
            
            return (
              <Card key={schedule.id} className="bg-slate-800/50 border-slate-700 hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-3">
                      {/* Header */}
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-700/50 rounded-lg">
                          <PlatformIcon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-white capitalize">
                            {schedule.platform}
                          </h3>
                          <p className="text-sm text-slate-400">
                            {scheduleContent?.title || "Untitled Content"}
                          </p>
                        </div>
                        <Badge className={statusColors[schedule.status]}>
                          {schedule.status}
                        </Badge>
                      </div>

                      {/* Content Preview */}
                      {schedule.postContent && (
                        <div className="bg-slate-700/30 rounded-lg p-3">
                          <p className="text-sm text-slate-300 line-clamp-2">
                            {schedule.postContent}
                          </p>
                        </div>
                      )}

                      {/* Hashtags */}
                      {schedule.hashtags && schedule.hashtags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {schedule.hashtags.slice(0, 5).map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs bg-slate-600/50 text-slate-300 border-slate-500">
                              {tag}
                            </Badge>
                          ))}
                          {schedule.hashtags.length > 5 && (
                            <Badge variant="outline" className="text-xs border-slate-500 text-slate-400">
                              +{schedule.hashtags.length - 5} more
                            </Badge>
                          )}
                        </div>
                      )}

                      {/* Timing */}
                      <div className="flex items-center gap-4 text-sm text-slate-400">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {format(new Date(scheduledTime), 'MMM d, yyyy h:mm a')}
                          </span>
                        </div>
                        {schedule.status === 'scheduled' && (
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>in {getTimeUntilPublication(scheduledTime)}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 ml-4">
                      {schedule.status === 'scheduled' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onStatusChange(schedule.id, 'cancelled')}
                          className="text-slate-400 hover:text-white border-slate-600 hover:bg-slate-700/50"
                        >
                          <Pause className="w-4 h-4" />
                        </Button>
                      )}
                      
                      {schedule.status === 'cancelled' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onStatusChange(schedule.id, 'scheduled')}
                          className="text-green-400 hover:text-green-300 border-green-600 hover:bg-green-900/20"
                        >
                          <Play className="w-4 h-4" />
                        </Button>
                      )}

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEdit(schedule)}
                        className="text-blue-400 hover:text-blue-300 border-blue-600 hover:bg-blue-900/20"
                      >
                        <Edit3 className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onDelete(schedule.id)}
                        className="text-red-400 hover:text-red-300 border-red-600 hover:bg-red-900/20"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}


import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const sort = searchParams.get('sort') || '-createdAt';

    let where: any = {
      userId: session.user.id
    };

    if (status) {
      // For content, we might want to filter by project status or content status
      where.project = {
        status: status.toUpperCase()
      };
    }

    // Parse sort parameter
    let orderBy: any = {};
    if (sort.startsWith('-')) {
      const field = sort.slice(1);
      orderBy[field === 'createdAt' ? 'createdAt' : field] = 'desc';
    } else {
      orderBy[sort === 'createdAt' ? 'createdAt' : sort] = 'asc';
    }

    const content = await prisma.generatedContent.findMany({
      where,
      orderBy,
      include: {
        project: true,
        user: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    return NextResponse.json(content);
  } catch (error) {
    console.error("Error fetching content:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const data = await request.json();

    const content = await prisma.generatedContent.create({
      data: {
        ...data,
        userId: session.user.id,
      },
      include: {
        project: true,
        user: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    return NextResponse.json(content);
  } catch (error) {
    console.error("Error creating content:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

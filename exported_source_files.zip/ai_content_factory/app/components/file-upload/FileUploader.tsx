
"use client";

import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, 
  File, 
  Image, 
  FileText, 
  Video, 
  Music,
  X,
  Check,
  AlertCircle,
  Loader2
} from 'lucide-react';
import toast from 'react-hot-toast';

interface FileUpload {
  id: string;
  file: File;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  url?: string;
  error?: string;
}

interface FileUploaderProps {
  accept?: Record<string, string[]>;
  maxSize?: number; // in bytes
  maxFiles?: number;
  onUploadComplete?: (files: { id: string; url: string; name: string; size: number }[]) => void;
  className?: string;
  multiple?: boolean;
  showPreview?: boolean;
}

const DEFAULT_ACCEPT = {
  'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp'],
  'application/pdf': ['.pdf'],
  'text/plain': ['.txt'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'text/csv': ['.csv'],
  'application/json': ['.json']
};

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

export function FileUploader({
  accept = DEFAULT_ACCEPT,
  maxSize = MAX_FILE_SIZE,
  maxFiles = 5,
  onUploadComplete,
  className = '',
  multiple = true,
  showPreview = true
}: FileUploaderProps) {
  const [uploads, setUploads] = useState<FileUpload[]>([]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newUploads: FileUpload[] = acceptedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      progress: 0,
      status: 'pending'
    }));

    setUploads(prev => [...prev, ...newUploads]);
    
    // Start uploading each file
    newUploads.forEach(upload => {
      uploadFile(upload);
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept,
    maxSize,
    maxFiles: maxFiles - uploads.length,
    multiple,
    disabled: uploads.length >= maxFiles
  });

  const uploadFile = async (upload: FileUpload) => {
    const formData = new FormData();
    formData.append('file', upload.file);
    formData.append('uploadId', upload.id);

    setUploads(prev => prev.map(u => 
      u.id === upload.id ? { ...u, status: 'uploading' } : u
    ));

    try {
      const xhr = new XMLHttpRequest();
      
      xhr.upload.addEventListener('progress', (event) => {
        if (event.lengthComputable) {
          const progress = (event.loaded / event.total) * 100;
          setUploads(prev => prev.map(u => 
            u.id === upload.id ? { ...u, progress } : u
          ));
        }
      });

      xhr.onload = () => {
        if (xhr.status === 200) {
          const result = JSON.parse(xhr.responseText);
          setUploads(prev => prev.map(u => 
            u.id === upload.id 
              ? { ...u, status: 'success', progress: 100, url: result.url } 
              : u
          ));
          
          toast.success(`${upload.file.name} uploaded successfully!`);
          
          // Call completion callback if provided
          if (onUploadComplete) {
            const completedFiles = uploads
              .filter(u => u.status === 'success' && u.url)
              .map(u => ({
                id: u.id,
                url: u.url!,
                name: u.file.name,
                size: u.file.size
              }));
            onUploadComplete(completedFiles);
          }
        } else {
          throw new Error('Upload failed');
        }
      };

      xhr.onerror = () => {
        setUploads(prev => prev.map(u => 
          u.id === upload.id 
            ? { ...u, status: 'error', error: 'Upload failed' } 
            : u
        ));
        toast.error(`Failed to upload ${upload.file.name}`);
      };

      xhr.open('POST', '/api/upload');
      xhr.send(formData);

    } catch (error) {
      setUploads(prev => prev.map(u => 
        u.id === upload.id 
          ? { ...u, status: 'error', error: 'Upload failed' } 
          : u
      ));
      toast.error(`Failed to upload ${upload.file.name}`);
    }
  };

  const removeUpload = (id: string) => {
    setUploads(prev => prev.filter(u => u.id !== id));
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <Image className="w-4 h-4" />;
    if (file.type.startsWith('video/')) return <Video className="w-4 h-4" />;
    if (file.type.startsWith('audio/')) return <Music className="w-4 h-4" />;
    if (file.type === 'application/pdf' || file.type.startsWith('text/')) return <FileText className="w-4 h-4" />;
    return <File className="w-4 h-4" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Drop Zone */}
      <Card className="border-2 border-dashed border-slate-600 bg-slate-800/50">
        <CardContent className="p-8">
          <div 
            {...getRootProps()} 
            className={`text-center cursor-pointer transition-colors ${
              isDragActive ? 'text-purple-400' : 'text-slate-400'
            }`}
          >
            <input {...getInputProps()} />
            <Upload className="w-12 h-12 mx-auto mb-4 text-slate-400" />
            
            {isDragActive ? (
              <p className="text-lg font-medium">Drop the files here...</p>
            ) : (
              <div>
                <p className="text-lg font-medium text-white mb-2">
                  Drop files here or click to browse
                </p>
                <p className="text-sm text-slate-400 mb-4">
                  Supports images, documents, and text files up to {formatFileSize(maxSize)}
                </p>
                <Button 
                  variant="outline" 
                  className="bg-purple-600/20 border-purple-400/20 text-purple-400 hover:bg-purple-600/30"
                  type="button"
                >
                  Choose Files
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Upload Progress */}
      {uploads.length > 0 && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Upload Progress</h3>
            <div className="space-y-3">
              {uploads.map((upload) => (
                <div key={upload.id} className="flex items-center space-x-3">
                  <div className="flex-shrink-0">
                    {getFileIcon(upload.file)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium text-white truncate">
                        {upload.file.name}
                      </p>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={upload.status === 'success' ? 'default' : 
                                  upload.status === 'error' ? 'destructive' : 
                                  'secondary'}
                          className="text-xs"
                        >
                          {upload.status}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeUpload(upload.id)}
                          className="h-6 w-6 p-0 text-slate-400 hover:text-white"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Progress 
                        value={upload.progress} 
                        className="flex-1 h-2"
                      />
                      <span className="text-xs text-slate-400">
                        {Math.round(upload.progress)}%
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
                      <span>{formatFileSize(upload.file.size)}</span>
                      {upload.status === 'success' && (
                        <Check className="w-3 h-3 text-green-400" />
                      )}
                      {upload.status === 'error' && (
                        <AlertCircle className="w-3 h-3 text-red-400" />
                      )}
                      {upload.status === 'uploading' && (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* File Preview */}
      {showPreview && uploads.some(u => u.status === 'success') && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Uploaded Files</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {uploads
                .filter(upload => upload.status === 'success')
                .map((upload) => (
                  <div key={upload.id} className="bg-slate-700/50 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      {getFileIcon(upload.file)}
                      <span className="text-sm font-medium text-white truncate">
                        {upload.file.name}
                      </span>
                    </div>
                    
                    {upload.file.type.startsWith('image/') && upload.url && (
                      <div className="aspect-video bg-slate-600 rounded overflow-hidden mb-2">
                        <img 
                          src={upload.url} 
                          alt={upload.file.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>{formatFileSize(upload.file.size)}</span>
                      {upload.url && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.open(upload.url, '_blank')}
                          className="h-6 px-2 text-xs text-purple-400 hover:text-purple-300"
                        >
                          View
                        </Button>
                      )}
                    </div>
                  </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}


// Content niche/topic suggestions
export const CONTENT_NICHE_SUGGESTIONS = [
  // Technology
  "Artificial Intelligence & Machine Learning",
  "Web Development & Programming",
  "Cybersecurity & Data Privacy",
  "Blockchain & Cryptocurrency",
  "Software Development",
  "Mobile App Development",
  "Cloud Computing & DevOps",
  "Internet of Things (IoT)",
  "Data Science & Analytics",
  "Tech Reviews & Gadgets",
  
  // Business & Marketing
  "Digital Marketing & SEO",
  "Social Media Marketing",
  "Content Marketing & Copywriting",
  "Email Marketing & Automation",
  "E-commerce & Online Business",
  "Entrepreneurship & Startups",
  "Personal Branding",
  "Lead Generation",
  "Sales & Conversion Optimization",
  "Affiliate Marketing",
  "Influencer Marketing",
  "B2B Marketing",
  "Growth Hacking",
  
  // Finance & Investment
  "Personal Finance & Budgeting",
  "Investment Strategies",
  "Stock Market & Trading",
  "Cryptocurrency Trading",
  "Real Estate Investment",
  "Financial Planning & Retirement",
  "Fintech & Digital Banking",
  
  // Health & Wellness
  "Fitness & Exercise",
  "Nutrition & Diet",
  "Mental Health & Mindfulness",
  "Wellness & Self-Care",
  "Weight Loss & Healthy Living",
  "Alternative Medicine",
  "Healthcare Innovation",
  
  // Lifestyle
  "Travel & Adventure",
  "Food & Cooking",
  "Fashion & Beauty",
  "Home Improvement & DIY",
  "Photography",
  "Arts & Crafts",
  "Music & Entertainment",
  "Sports & Recreation",
  
  // Education & Professional Development
  "Online Learning & Courses",
  "Career Development",
  "Professional Skills",
  "Leadership & Management",
  "Productivity & Time Management",
  "Remote Work & Freelancing",
  
  // Industry Specific
  "Healthcare & Medical",
  "Legal & Law",
  "Automotive & Transportation",
  "Real Estate",
  "Construction & Architecture",
  "Agriculture & Farming",
  "Manufacturing & Industrial",
  "Retail & E-commerce",
  "Hospitality & Tourism",
  "Green Energy & Sustainability"
];

// Target audience suggestions
export const TARGET_AUDIENCE_SUGGESTIONS = [
  // Professional/Business
  "Small Business Owners",
  "Entrepreneurs & Startup Founders",
  "C-Suite Executives & Decision Makers",
  "Marketing Professionals",
  "Sales Teams & Representatives",
  "Digital Marketers",
  "Content Creators",
  "Freelancers & Independent Contractors",
  "Remote Workers",
  "Consultants & Coaches",
  "Real Estate Professionals",
  "Financial Advisors",
  
  // Technology
  "Software Developers & Engineers",
  "Web Developers",
  "Data Scientists & Analysts",
  "IT Professionals",
  "Cybersecurity Experts",
  "Tech Enthusiasts",
  "SaaS Users & Decision Makers",
  "DevOps Engineers",
  "Product Managers",
  
  // Demographics
  "Millennials (Ages 25-40)",
  "Gen Z (Ages 18-27)",
  "Gen X (Ages 41-56)",
  "Baby Boomers (Ages 57+)",
  "Working Parents",
  "College Students",
  "Recent Graduates",
  "Retirees",
  "Stay-at-Home Parents",
  
  // Interests & Lifestyle
  "Health & Fitness Enthusiasts",
  "Wellness & Self-Care Focused",
  "Fashion & Beauty Conscious",
  "Travel Enthusiasts",
  "Food Lovers & Home Cooks",
  "DIY & Home Improvement Enthusiasts",
  "Pet Owners",
  "Outdoor & Adventure Seekers",
  "Sports Fans",
  "Music & Entertainment Lovers",
  
  // Financial
  "Investors & Traders",
  "Personal Finance Conscious",
  "High-Income Earners",
  "Budget-Conscious Consumers",
  "Cryptocurrency Enthusiasts",
  "First-Time Home Buyers",
  "Retirement Planners",
  
  // Shopping Behavior
  "Online Shoppers",
  "Bargain Hunters & Deal Seekers",
  "Premium Brand Customers",
  "Eco-Conscious Consumers",
  "Early Adopters of New Products",
  "Mobile-First Users",
  "Social Media Active Users",
  
  // Education & Learning
  "Lifelong Learners",
  "Online Course Students",
  "Professional Development Seekers",
  "Skill Development Focused",
  "Certification Pursuers",
  
  // Geographic
  "Urban Professionals",
  "Suburban Families",
  "Rural Communities",
  "International Audiences",
  "Local Community Members",
  
  // Specific Niches
  "B2B Decision Makers",
  "E-commerce Store Owners",
  "Content Marketing Managers",
  "Social Media Managers",
  "SEO Specialists",
  "Affiliate Marketers",
  "Course Creators & Educators",
  "Coaches & Mentors",
  "Agency Owners",
  "Influencers & Content Creators"
];


"use client";

import { useState } from "react";
import { signOut, useSession } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Sparkles, 
  LogOut, 
  Plus, 
  FileText, 
  BarChart3, 
  Target,
  Search,
  Filter,
  Calendar,
  TrendingUp,
  Zap,
  User,
  Settings,
  Bell,
  Menu,
  X
} from "lucide-react";
import Link from "next/link";

interface DashboardProps {
  user: {
    id: string;
    name: string | null;
    email: string;
    companyName: string | null;
    createdAt: Date;
  };
  projects: any[];
  recentContent: any[];
  templates: any[];
  stats: {
    totalProjects: number;
    totalContent: number;
    publishedContent: number;
  };
}

export default function DashboardClient({ 
  user, 
  projects, 
  recentContent, 
  templates, 
  stats 
}: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { data: session } = useSession();

  const handleSignOut = () => {
    signOut({ callbackUrl: "/" });
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'TEXT': return <FileText className="w-4 h-4" />;
      case 'SOCIAL_POST': return <Target className="w-4 h-4" />;
      case 'EMAIL': return <FileText className="w-4 h-4" />;
      case 'BLOG_POST': return <FileText className="w-4 h-4" />;
      case 'AD_COPY': return <Zap className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-40" 
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 z-50 w-64 h-full bg-slate-800/50 backdrop-blur-sm border-r border-slate-700 transform transition-transform duration-300 ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0`}>
        <div className="p-6">
          {/* Logo */}
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-white">AI Content Factory</h1>
            </div>
          </div>

          {/* User Info */}
          <div className="bg-slate-700/50 rounded-lg p-4 mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">{user?.name || 'User'}</p>
                <p className="text-xs text-slate-400">{user?.companyName || 'Personal'}</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="space-y-2">
            <Link 
              href="/dashboard" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg bg-purple-600/20 text-purple-300 border border-purple-600/30"
            >
              <BarChart3 className="w-4 h-4" />
              <span className="text-sm font-medium">Dashboard</span>
            </Link>
            
            <Link 
              href="/create" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm font-medium">Create Content</span>
            </Link>

            <Link 
              href="/automated" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">Automated</span>
            </Link>
            
            <Link 
              href="/projects" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span className="text-sm font-medium">Projects</span>
            </Link>

            <Link 
              href="/publishing" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <Target className="w-4 h-4" />
              <span className="text-sm font-medium">Publishing</span>
            </Link>
            
            <Link 
              href="/templates" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <Target className="w-4 h-4" />
              <span className="text-sm font-medium">Templates</span>
            </Link>

            <Link 
              href="/workflows" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">Workflows</span>
            </Link>

            <Link 
              href="/files" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span className="text-sm font-medium">Files</span>
            </Link>

            <Link 
              href="/settings" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700/50 transition-colors"
            >
              <Settings className="w-4 h-4" />
              <span className="text-sm font-medium">Settings</span>
            </Link>
          </nav>

          {/* Sign Out */}
          <div className="absolute bottom-6 left-6 right-6">
            <Button 
              onClick={handleSignOut}
              variant="ghost"
              className="w-full justify-start text-slate-400 hover:text-white hover:bg-slate-700/50"
            >
              <LogOut className="w-4 h-4 mr-3" />
              Sign Out
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 min-h-screen">
        {/* Top Header */}
        <header className="bg-slate-800/30 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost" 
                size="icon"
                className="lg:hidden text-white"
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              >
                {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
              <div>
                <h2 className="text-2xl font-semibold text-white">Welcome back, {user?.name?.split(' ')?.[0] || 'Creator'}!</h2>
                <p className="text-slate-400">Let's create something amazing today</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search projects..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                />
              </div>
              
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                <Bell className="w-5 h-5" />
              </Button>
              
              <Link href="/settings">
                <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                  <Settings className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
        </header>

        <div className="p-6 space-y-8">
          {/* Stats Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-200">Total Projects</CardTitle>
                <FileText className="w-4 h-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.totalProjects || 0}</div>
                <p className="text-xs text-slate-400 mt-1">+12% from last month</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-200">Content Generated</CardTitle>
                <Zap className="w-4 h-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.totalContent || 0}</div>
                <p className="text-xs text-slate-400 mt-1">+25% from last month</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-200">Published</CardTitle>
                <TrendingUp className="w-4 h-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.publishedContent || 0}</div>
                <p className="text-xs text-slate-400 mt-1">+8% from last month</p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Quick Actions</CardTitle>
              <CardDescription className="text-slate-400">
                Jump right into creating your next piece of content
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                <Link href="/create?type=social-post">
                  <Card className="bg-gradient-to-br from-purple-600/20 to-blue-600/20 border-purple-500/30 hover:from-purple-600/30 hover:to-blue-600/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <Target className="w-8 h-8 text-purple-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-medium text-white">Social Post</p>
                      <p className="text-xs text-slate-400">Create engaging social content</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/create?type=blog-post">
                  <Card className="bg-gradient-to-br from-blue-600/20 to-cyan-600/20 border-blue-500/30 hover:from-blue-600/30 hover:to-cyan-600/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <FileText className="w-8 h-8 text-blue-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-medium text-white">Blog Post</p>
                      <p className="text-xs text-slate-400">Write comprehensive articles</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/create?type=email">
                  <Card className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 border-green-500/30 hover:from-green-600/30 hover:to-emerald-600/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <FileText className="w-8 h-8 text-green-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-medium text-white">Email</p>
                      <p className="text-xs text-slate-400">Design email campaigns</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/create?type=ad-copy">
                  <Card className="bg-gradient-to-br from-orange-600/20 to-red-600/20 border-orange-500/30 hover:from-orange-600/30 hover:to-red-600/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <Zap className="w-8 h-8 text-orange-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-medium text-white">Ad Copy</p>
                      <p className="text-xs text-slate-400">Create persuasive ads</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/automated">
                  <Card className="bg-gradient-to-br from-violet-600/20 to-indigo-600/20 border-violet-500/30 hover:from-violet-600/30 hover:to-indigo-600/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <Zap className="w-8 h-8 text-violet-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-medium text-white">Automated</p>
                      <p className="text-xs text-slate-400">Set up automation</p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/publishing">
                  <Card className="bg-gradient-to-br from-teal-600/20 to-emerald-600/20 border-teal-500/30 hover:from-teal-600/30 hover:to-emerald-600/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <Target className="w-8 h-8 text-teal-400 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-medium text-white">Publishing</p>
                      <p className="text-xs text-slate-400">Manage publications</p>
                    </CardContent>
                  </Card>
                </Link>
              </div>
            </CardContent>
          </Card>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Recent Projects */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Recent Projects</CardTitle>
                    <CardDescription className="text-slate-400">Your latest content projects</CardDescription>
                  </div>
                  <Link href="/projects">
                    <Button variant="ghost" size="sm" className="text-purple-400 hover:text-purple-300">
                      View All
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {projects?.slice(0, 3)?.map((project, index) => (
                    <div key={project?.id || index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                      <div className="flex items-center space-x-3">
                        {getContentTypeIcon(project?.type || 'TEXT')}
                        <div>
                          <p className="font-medium text-white">{project?.title || 'Untitled Project'}</p>
                          <p className="text-sm text-slate-400">{project?._count?.generatedContent || 0} content pieces</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-slate-400">{formatDate(project?.updatedAt)}</p>
                        <div className={`inline-block px-2 py-1 rounded-full text-xs ${
                          project?.status === 'PUBLISHED' ? 'bg-green-500/20 text-green-400' :
                          project?.status === 'IN_PROGRESS' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-slate-500/20 text-slate-400'
                        }`}>
                          {project?.status?.toLowerCase()?.replace('_', ' ') || 'draft'}
                        </div>
                      </div>
                    </div>
                  )) || (
                    <div className="text-center py-8">
                      <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                      <p className="text-slate-400">No projects yet</p>
                      <Link href="/create">
                        <Button className="mt-2 bg-gradient-to-r from-purple-600 to-blue-600">
                          Create Your First Project
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Popular Templates */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Popular Templates</CardTitle>
                    <CardDescription className="text-slate-400">Start with proven templates</CardDescription>
                  </div>
                  <Link href="/templates">
                    <Button variant="ghost" size="sm" className="text-purple-400 hover:text-purple-300">
                      View All
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {templates?.slice(0, 4)?.map((template, index) => (
                    <div key={template?.id || index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg hover:bg-slate-700/50 transition-colors cursor-pointer">
                      <div className="flex items-center space-x-3">
                        {getContentTypeIcon(template?.contentType || 'TEXT')}
                        <div>
                          <p className="font-medium text-white">{template?.name || 'Template'}</p>
                          <p className="text-sm text-slate-400">{template?.category || 'General'}</p>
                        </div>
                      </div>
                      <Link href={`/create?template=${template?.id}`}>
                        <Button size="sm" variant="ghost" className="text-purple-400 hover:text-purple-300">
                          Use Template
                        </Button>
                      </Link>
                    </div>
                  )) || (
                    <div className="text-center py-8">
                      <Target className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                      <p className="text-slate-400">Loading templates...</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

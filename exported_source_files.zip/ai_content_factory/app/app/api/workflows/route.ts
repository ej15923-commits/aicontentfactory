
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// In-memory storage for demo purposes
// In a real app, this would be stored in a database
let workflows: Array<{
  id: string;
  name: string;
  description: string;
  trigger: string;
  actions: string[];
  status: 'active' | 'inactive';
  lastRun?: string;
  createdAt: string;
  userId: string;
}> = [];

export async function GET(request: NextRequest) {
  try {
    // In a real app, you would get the user ID from session
    const userId = 'current-user';
    
    const userWorkflows = workflows.filter(w => w.userId === userId);
    
    return NextResponse.json(userWorkflows);
  } catch (error) {
    console.error('Error fetching workflows:', error);
    return NextResponse.json(
      { error: 'Failed to fetch workflows' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, description, trigger, actions } = await request.json();
    
    if (!name || !description || !trigger || !actions || actions.length === 0) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // In a real app, you would get the user ID from session
    const userId = 'current-user';
    
    const workflow = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      description,
      trigger,
      actions: actions.filter((action: string) => action.trim() !== ''),
      status: 'inactive' as const,
      createdAt: new Date().toISOString(),
      userId
    };
    
    workflows.push(workflow);
    
    console.log(`✅ Created workflow: ${name}`);
    
    return NextResponse.json(workflow);
  } catch (error) {
    console.error('Error creating workflow:', error);
    return NextResponse.json(
      { error: 'Failed to create workflow' },
      { status: 500 }
    );
  }
}

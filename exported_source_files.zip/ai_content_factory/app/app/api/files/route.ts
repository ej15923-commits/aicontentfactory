
import { NextRequest, NextResponse } from 'next/server';
import { readdir, stat, unlink } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

interface FileInfo {
  id: string;
  name: string;
  originalName: string;
  size: number;
  type: string;
  url: string;
  uploadedAt: Date;
}

export async function GET(request: NextRequest) {
  try {
    const uploadsDir = path.join(process.cwd(), 'public/uploads');
    
    if (!existsSync(uploadsDir)) {
      return NextResponse.json([]);
    }

    const files = await readdir(uploadsDir);
    const fileInfos: FileInfo[] = [];

    for (const file of files) {
      const filePath = path.join(uploadsDir, file);
      const stats = await stat(filePath);
      
      if (stats.isFile()) {
        // Extract original name from filename format: timestamp_random_originalname
        const parts = file.split('_');
        let originalName = file;
        if (parts.length >= 3) {
          originalName = parts.slice(2).join('_');
        }

        fileInfos.push({
          id: file,
          name: file,
          originalName,
          size: stats.size,
          type: getFileType(file),
          url: `/uploads/${file}`,
          uploadedAt: stats.birthtime
        });
      }
    }

    // Sort by upload date (newest first)
    fileInfos.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());

    return NextResponse.json(fileInfos);
  } catch (error) {
    console.error('Error listing files:', error);
    return NextResponse.json(
      { error: 'Failed to list files' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const fileName = searchParams.get('filename');

    if (!fileName) {
      return NextResponse.json(
        { error: 'Filename is required' },
        { status: 400 }
      );
    }

    const filePath = path.join(process.cwd(), 'public/uploads', fileName);
    
    if (!existsSync(filePath)) {
      return NextResponse.json(
        { error: 'File not found' },
        { status: 404 }
      );
    }

    await unlink(filePath);
    
    console.log(`✅ File deleted: ${fileName}`);

    return NextResponse.json({ 
      success: true, 
      message: 'File deleted successfully' 
    });

  } catch (error) {
    console.error('Error deleting file:', error);
    return NextResponse.json(
      { error: 'Failed to delete file' },
      { status: 500 }
    );
  }
}

function getFileType(filename: string): string {
  const ext = path.extname(filename).toLowerCase();
  
  const typeMap: Record<string, string> = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.pdf': 'application/pdf',
    '.txt': 'text/plain',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.csv': 'text/csv',
    '.json': 'application/json'
  };

  return typeMap[ext] || 'application/octet-stream';
}

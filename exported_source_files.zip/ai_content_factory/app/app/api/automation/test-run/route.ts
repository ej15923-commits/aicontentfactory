
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { PrismaClient, ContentType, ProjectStatus } from "@prisma/client";

const prisma = new PrismaClient();

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const { userId, config } = await request.json();

    if (userId !== session.user.id) {
      return NextResponse.json(
        { error: "Forbidden" },
        { status: 403 }
      );
    }

    // Generate a single piece of test content for each selected content type
    const generatedContent = [];

    for (const [contentType, enabled] of Object.entries(config.contentTypes)) {
      if (!enabled) continue;

      const contentTypeLabel = getContentTypeLabel(contentType);
      
      // Generate content based on the automation config
      const content = await generateTestContent({
        type: contentType,
        niche: config.niche,
        targetAudience: config.targetAudience,
        brandVoice: config.brandVoice,
        affiliateLink: config.affiliateLink
      });

      // Create a temporary project for test content
      let testProject = await prisma.contentProject.findFirst({
        where: {
          userId: session.user.id,
          title: "Test Run Content"
        }
      });

      if (!testProject) {
        testProject = await prisma.contentProject.create({
          data: {
            title: "Test Run Content",
            description: "Content generated from test runs",
            type: getContentTypeEnum(contentType),
            status: ProjectStatus.DRAFT,
            userId: session.user.id
          }
        });
      }

      // Save test content to database
      const savedContent = await prisma.generatedContent.create({
        data: {
          title: `[TEST] ${content.title}`,
          content: content.body,
          contentType: getContentTypeEnum(contentType),
          projectId: testProject.id,
          userId: session.user.id,
          generationData: {
            isTest: true,
            generatedBy: "test-run",
            automationConfig: config,
            generatedAt: new Date().toISOString()
          }
        },
      });

      generatedContent.push(savedContent);
    }

    return NextResponse.json({
      success: true,
      message: `Generated ${generatedContent.length} test content pieces`,
      generatedContent: generatedContent.map(content => ({
        id: content.id,
        title: content.title,
        type: getContentTypeLabel(Object.keys(config.contentTypes).find(key => config.contentTypes[key]) || ""),
        contentType: content.contentType
      }))
    });

  } catch (error) {
    console.error("Test run error:", error);
    return NextResponse.json(
      { error: "Failed to run test automation" },
      { status: 500 }
    );
  }
}

function getContentTypeLabel(type: string): string {
  const labels: Record<string, string> = {
    socialPosts: "Social Media Post",
    blogPosts: "Blog Post", 
    emails: "Email",
    adCopy: "Ad Copy"
  };
  return labels[type] || "Content";
}

function getContentTypeEnum(type: string): ContentType {
  const enums: Record<string, ContentType> = {
    socialPosts: ContentType.SOCIAL_POST,
    blogPosts: ContentType.BLOG_POST, 
    emails: ContentType.EMAIL,
    adCopy: ContentType.AD_COPY
  };
  return enums[type] || ContentType.TEXT;
}

async function generateTestContent({
  type,
  niche,
  targetAudience, 
  brandVoice,
  affiliateLink
}: {
  type: string;
  niche: string;
  targetAudience: string;
  brandVoice: string;
  affiliateLink: string;
}) {
  // Create prompts based on content type
  const prompts = {
    socialPosts: `Create a ${brandVoice} social media post about ${niche} for ${targetAudience}. Make it engaging and include relevant hashtags.`,
    blogPosts: `Write a ${brandVoice} blog post outline about ${niche} targeting ${targetAudience}. Include a compelling title and 3-5 main sections.`,
    emails: `Draft a ${brandVoice} email subject line and preview text about ${niche} for ${targetAudience}.`,
    adCopy: `Write ${brandVoice} ad copy about ${niche} targeting ${targetAudience}. Include a strong headline and call-to-action.`
  };

  const prompt = prompts[type as keyof typeof prompts] || prompts.socialPosts;
  
  // For now, generate sample content. In a real implementation, 
  // this would call an AI service like OpenAI or your preferred LLM
  const sampleContent = generateSampleContent(type, niche, targetAudience, brandVoice, affiliateLink);

  return sampleContent;
}

function generateSampleContent(
  type: string, 
  niche: string, 
  targetAudience: string, 
  brandVoice: string,
  affiliateLink: string
) {
  const affiliate = affiliateLink ? `\n\nLearn more: ${affiliateLink}` : "";
  
  switch (type) {
    case 'socialPosts':
      return {
        title: `${niche} Insights for ${targetAudience}`,
        body: `🚀 Exciting developments in ${niche}! 

As ${targetAudience}, you need to stay ahead of the curve. Here's what's trending:

✅ Innovation is accelerating
✅ New opportunities emerging  
✅ Community is growing stronger

What's your take on the latest ${niche} trends? Share below! 👇

#${niche.replace(/\s+/g, '')} #Innovation #Growth${affiliate}`
      };
      
    case 'blogPosts':
      return {
        title: `The Ultimate ${niche} Guide for ${targetAudience}`,
        body: `# The Ultimate ${niche} Guide for ${targetAudience}

## Introduction
In today's rapidly evolving landscape, ${targetAudience} need comprehensive insights into ${niche}.

## Key Sections:
1. **Understanding the Basics** - Foundation knowledge every ${targetAudience.split(' ')[0]} should know
2. **Current Trends** - What's happening in ${niche} right now  
3. **Best Practices** - Proven strategies that work
4. **Future Outlook** - Where ${niche} is heading
5. **Getting Started** - Your next steps

## Conclusion
${niche} presents incredible opportunities for ${targetAudience}. The key is staying informed and taking action.${affiliate}`
      };
      
    case 'emails':
      return {
        title: `🔥 ${niche} Breakthrough for ${targetAudience}`,
        body: `Subject: 🔥 ${niche} Breakthrough for ${targetAudience}
Preview: Don't miss this game-changing insight...

Dear ${targetAudience},

Big news in the ${niche} world! 

This breakthrough could change everything for professionals like you. Here's what you need to know...

[Content preview - This would be expanded in the full email]${affiliate}

Best regards,
Your ${niche} Team`
      };
      
    case 'adCopy':
      return {
        title: `Transform Your ${niche} Results Now`,
        body: `🎯 **Transform Your ${niche} Results Now**

Are you a ${targetAudience.split(' ')[0]} struggling with ${niche}?

✨ **Get Results Fast:**
→ Proven strategies that work
→ Expert guidance included
→ Start seeing improvements today

**Limited Time: Special offer for ${targetAudience}**

👆 **Click to Transform Your ${niche} Journey**${affiliate}`
      };
      
    default:
      return {
        title: `${niche} Content for ${targetAudience}`,
        body: `Quality ${niche} content specifically created for ${targetAudience} with a ${brandVoice} voice.${affiliate}`
      };
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // For now, return mock data since we don't have workflows in the database schema
    const mockWorkflows = [
      {
        id: '1',
        name: 'Daily Social Media Posts',
        description: 'Automatically generate and publish social media content every day',
        trigger: 'schedule',
        actions: ['generate-content', 'publish-social'],
        status: 'active',
        lastRun: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        name: 'Weekly Blog Posts',
        description: 'Generate comprehensive blog posts every week',
        trigger: 'schedule',
        actions: ['generate-content', 'generate-image'],
        status: 'inactive',
        createdAt: new Date().toISOString(),
      },
    ];

    return NextResponse.json(mockWorkflows);
  } catch (error) {
    console.error('Error fetching workflows:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { name, description, trigger, actions } = body;

    // For now, return a mock workflow since we don't have workflows in the database schema
    const newWorkflow = {
      id: Date.now().toString(),
      name,
      description,
      trigger,
      actions,
      status: 'inactive' as const,
      createdAt: new Date().toISOString(),
    };

    return NextResponse.json(newWorkflow);
  } catch (error) {
    console.error('Error creating workflow:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}



"use client";

import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Music,
  Youtube,
  Settings,
  CheckCircle,
  AlertCircle,
  Link2,
  Key,
  User,
  Shield
} from "lucide-react";
import toast from "react-hot-toast";

interface PlatformConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectionUpdate: () => void;
}

interface PlatformConfig {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  fields: {
    label: string;
    key: string;
    type: 'text' | 'password';
    placeholder: string;
    description?: string;
  }[];
  instructions: string[];
}

const platformConfigs: PlatformConfig[] = [
  {
    id: 'facebook',
    name: 'Facebook',
    icon: Facebook,
    color: 'text-blue-600',
    fields: [
      { label: 'Page Access Token', key: 'accessToken', type: 'password', placeholder: 'Enter your Facebook Page Access Token', description: 'Long-lived page access token for posting' },
      { label: 'Page ID', key: 'pageId', type: 'text', placeholder: 'Enter your Facebook Page ID', description: 'Numeric ID of your Facebook page' },
    ],
    instructions: [
      'Go to Facebook Developers (developers.facebook.com)',
      'Create a new app or use existing app',
      'Add Facebook Login and Pages API',
      'Generate a Page Access Token',
      'Get your Page ID from your Facebook page settings'
    ]
  },
  {
    id: 'instagram',
    name: 'Instagram',
    icon: Instagram,
    color: 'text-pink-600',
    fields: [
      { label: 'Access Token', key: 'accessToken', type: 'password', placeholder: 'Enter your Instagram Access Token', description: 'Instagram Basic Display API access token' },
      { label: 'User ID', key: 'userId', type: 'text', placeholder: 'Enter your Instagram User ID', description: 'Your Instagram account user ID' },
    ],
    instructions: [
      'Go to Facebook Developers (developers.facebook.com)',
      'Create an app with Instagram Basic Display',
      'Generate User Access Token',
      'Get your User ID from the API response'
    ]
  },
  {
    id: 'twitter',
    name: 'Twitter',
    icon: Twitter,
    color: 'text-sky-600',
    fields: [
      { label: 'API Key', key: 'apiKey', type: 'password', placeholder: 'Enter your Twitter API Key' },
      { label: 'API Secret', key: 'apiSecret', type: 'password', placeholder: 'Enter your Twitter API Secret' },
      { label: 'Access Token', key: 'accessToken', type: 'password', placeholder: 'Enter your Access Token' },
      { label: 'Access Token Secret', key: 'accessTokenSecret', type: 'password', placeholder: 'Enter your Access Token Secret' },
    ],
    instructions: [
      'Go to Twitter Developer Portal (developer.twitter.com)',
      'Create a new project and app',
      'Generate API keys and tokens',
      'Make sure you have elevated access for posting'
    ]
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    icon: Linkedin,
    color: 'text-blue-700',
    fields: [
      { label: 'Client ID', key: 'clientId', type: 'text', placeholder: 'Enter your LinkedIn Client ID' },
      { label: 'Client Secret', key: 'clientSecret', type: 'password', placeholder: 'Enter your LinkedIn Client Secret' },
      { label: 'Access Token', key: 'accessToken', type: 'password', placeholder: 'Enter your Access Token', description: 'OAuth 2.0 access token for LinkedIn API' },
    ],
    instructions: [
      'Go to LinkedIn Developer Portal (developer.linkedin.com)',
      'Create a new app',
      'Add Sign In with LinkedIn and Share on LinkedIn products',
      'Generate OAuth 2.0 credentials'
    ]
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    icon: Music,
    color: 'text-black',
    fields: [
      { label: 'Client Key', key: 'clientKey', type: 'text', placeholder: 'Enter your TikTok Client Key' },
      { label: 'Client Secret', key: 'clientSecret', type: 'password', placeholder: 'Enter your TikTok Client Secret' },
      { label: 'Access Token', key: 'accessToken', type: 'password', placeholder: 'Enter your Access Token', description: 'OAuth access token for TikTok API' },
    ],
    instructions: [
      'Go to TikTok Developers (developers.tiktok.com)',
      'Create a new app',
      'Apply for Content Posting API access',
      'Generate OAuth credentials'
    ]
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: Youtube,
    color: 'text-red-600',
    fields: [
      { label: 'Client ID', key: 'clientId', type: 'text', placeholder: 'Enter your YouTube Client ID' },
      { label: 'Client Secret', key: 'clientSecret', type: 'password', placeholder: 'Enter your YouTube Client Secret' },
      { label: 'Refresh Token', key: 'refreshToken', type: 'password', placeholder: 'Enter your Refresh Token', description: 'OAuth 2.0 refresh token for YouTube API' },
    ],
    instructions: [
      'Go to Google Cloud Console (console.cloud.google.com)',
      'Enable YouTube Data API v3',
      'Create OAuth 2.0 credentials',
      'Generate refresh token using OAuth flow'
    ]
  }
];

export default function PlatformConnectionModal({ 
  isOpen, 
  onClose, 
  onConnectionUpdate 
}: PlatformConnectionModalProps) {
  const [activeTab, setActiveTab] = useState('facebook');
  const [platformData, setPlatformData] = useState<Record<string, Record<string, string>>>({});
  const [connectedPlatforms, setConnectedPlatforms] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [savingPlatform, setSavingPlatform] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadPlatformConnections();
    }
  }, [isOpen]);

  const loadPlatformConnections = async () => {
    try {
      const response = await fetch('/api/platforms/connections');
      if (response.ok) {
        const connections = await response.json();
        const connected = new Set<string>();
        const data: Record<string, Record<string, string>> = {};
        
        connections.forEach((conn: any) => {
          connected.add(conn.platform as string);
          data[conn.platform] = conn.credentials || {};
        });
        
        setConnectedPlatforms(connected);
        setPlatformData(data);
      }
    } catch (error) {
      console.error('Error loading platform connections:', error);
    }
  };

  const handleFieldChange = (platform: string, field: string, value: string) => {
    setPlatformData(prev => ({
      ...prev,
      [platform]: {
        ...prev[platform],
        [field]: value
      }
    }));
  };

  const handleSavePlatform = async (platformId: string) => {
    const platformConfig = platformConfigs.find(p => p.id === platformId);
    if (!platformConfig) return;

    const data = platformData[platformId] || {};
    
    // Validate required fields
    for (const field of platformConfig.fields) {
      if (!data[field.key]?.trim()) {
        toast.error(`Please enter ${field.label} for ${platformConfig.name}`);
        return;
      }
    }

    setSavingPlatform(platformId);
    
    try {
      const response = await fetch('/api/platforms/connect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          platform: platformId,
          credentials: data
        }),
      });

      if (response.ok) {
        setConnectedPlatforms(prev => new Set([...prev, platformId]));
        toast.success(`${platformConfig.name} connected successfully!`);
        onConnectionUpdate();
      } else {
        const error = await response.json();
        toast.error(error.message || `Failed to connect to ${platformConfig.name}`);
      }
    } catch (error) {
      console.error('Connection error:', error);
      toast.error(`Failed to connect to ${platformConfig.name}. Please try again.`);
    } finally {
      setSavingPlatform(null);
    }
  };

  const handleDisconnectPlatform = async (platformId: string) => {
    const platformConfig = platformConfigs.find(p => p.id === platformId);
    if (!platformConfig) return;

    setSavingPlatform(platformId);
    
    try {
      const response = await fetch('/api/platforms/disconnect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ platform: platformId }),
      });

      if (response.ok) {
        setConnectedPlatforms(prev => {
          const newSet = new Set(prev);
          newSet.delete(platformId);
          return newSet;
        });
        setPlatformData(prev => ({
          ...prev,
          [platformId]: {}
        }));
        toast.success(`${platformConfig.name} disconnected successfully!`);
        onConnectionUpdate();
      } else {
        toast.error(`Failed to disconnect ${platformConfig.name}`);
      }
    } catch (error) {
      console.error('Disconnection error:', error);
      toast.error(`Failed to disconnect ${platformConfig.name}. Please try again.`);
    } finally {
      setSavingPlatform(null);
    }
  };

  const testConnection = async (platformId: string) => {
    setSavingPlatform(platformId);
    
    try {
      const response = await fetch('/api/platforms/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ platform: platformId }),
      });

      if (response.ok) {
        toast.success(`${platformConfigs.find(p => p.id === platformId)?.name} connection is working!`);
      } else {
        toast.error(`${platformConfigs.find(p => p.id === platformId)?.name} connection failed`);
      }
    } catch (error) {
      console.error('Test connection error:', error);
      toast.error('Failed to test connection');
    } finally {
      setSavingPlatform(null);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-700 text-white">
        <DialogHeader className="border-b border-slate-700 pb-4">
          <DialogTitle className="flex items-center gap-2 text-xl text-white">
            <Settings className="w-6 h-6 text-purple-400" />
            Platform Connections
          </DialogTitle>
          <DialogDescription className="text-slate-300">
            Connect your social media accounts to enable automated publishing
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Connection Status Overview */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {platformConfigs.map((platform) => {
              const Icon = platform.icon;
              const isConnected = connectedPlatforms.has(platform.id);
              
              return (
                <Card key={platform.id} className="bg-slate-800 border-slate-600">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-5 h-5 ${platform.color}`} />
                        <span className="font-medium text-white">{platform.name}</span>
                      </div>
                      {isConnected ? (
                        <Badge className="bg-green-600 text-white">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Connected
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="bg-slate-700 text-slate-300">
                          <AlertCircle className="w-3 h-3 mr-1" />
                          Not Connected
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Platform Configuration Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-6 bg-slate-800 border-slate-600">
              {platformConfigs.map((platform) => {
                const Icon = platform.icon;
                return (
                  <TabsTrigger
                    key={platform.id}
                    value={platform.id}
                    className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                  >
                    <Icon className="w-4 h-4 mr-1" />
                    {platform.name}
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {platformConfigs.map((platform) => {
              const Icon = platform.icon;
              const isConnected = connectedPlatforms.has(platform.id);
              const data = platformData[platform.id] || {};
              const isSaving = savingPlatform === platform.id;

              return (
                <TabsContent key={platform.id} value={platform.id} className="space-y-4">
                  <Card className="bg-slate-800 border-slate-600">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-white">
                        <Icon className={`w-5 h-5 ${platform.color}`} />
                        {platform.name} Configuration
                        {isConnected && (
                          <Badge className="bg-green-600 text-white ml-2">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Connected
                          </Badge>
                        )}
                      </CardTitle>
                      <CardDescription className="text-slate-300">
                        Enter your {platform.name} API credentials to enable posting
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* API Fields */}
                      <div className="space-y-4">
                        {platform.fields.map((field) => (
                          <div key={field.key} className="space-y-2">
                            <Label htmlFor={`${platform.id}-${field.key}`} className="flex items-center gap-2 text-white">
                              {field.type === 'password' ? <Key className="w-4 h-4" /> : <User className="w-4 h-4" />}
                              {field.label}
                            </Label>
                            <Input
                              id={`${platform.id}-${field.key}`}
                              type={field.type}
                              placeholder={field.placeholder}
                              value={data[field.key] || ''}
                              onChange={(e) => handleFieldChange(platform.id, field.key, e.target.value)}
                              className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                            />
                            {field.description && (
                              <p className="text-xs text-slate-400">{field.description}</p>
                            )}
                          </div>
                        ))}
                      </div>

                      {/* Instructions */}
                      <Card className="bg-slate-700 border-slate-600">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm text-white">Setup Instructions</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ol className="list-decimal list-inside space-y-1 text-sm text-slate-300">
                            {platform.instructions.map((instruction, index) => (
                              <li key={index}>{instruction}</li>
                            ))}
                          </ol>
                        </CardContent>
                      </Card>

                      {/* Actions */}
                      <div className="flex gap-3 pt-4 border-t border-slate-600">
                        {isConnected ? (
                          <>
                            <Button
                              onClick={() => testConnection(platform.id)}
                              disabled={isSaving}
                              variant="outline"
                              className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                            >
                              {isSaving ? 'Testing...' : 'Test Connection'}
                            </Button>
                            <Button
                              onClick={() => handleSavePlatform(platform.id)}
                              disabled={isSaving}
                              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                            >
                              {isSaving ? 'Updating...' : 'Update Connection'}
                            </Button>
                            <Button
                              onClick={() => handleDisconnectPlatform(platform.id)}
                              disabled={isSaving}
                              variant="destructive"
                            >
                              Disconnect
                            </Button>
                          </>
                        ) : (
                          <Button
                            onClick={() => handleSavePlatform(platform.id)}
                            disabled={isSaving}
                            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                          >
                            {isSaving ? (
                              <div className="flex items-center gap-2">
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                Connecting...
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <Link2 className="w-4 h-4" />
                                Connect {platform.name}
                              </div>
                            )}
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              );
            })}
          </Tabs>

          {/* Close Button */}
          <div className="flex justify-end pt-4 border-t border-slate-600">
            <Button 
              onClick={onClose}
              variant="outline"
              className="border-slate-600 text-white hover:bg-slate-700"
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

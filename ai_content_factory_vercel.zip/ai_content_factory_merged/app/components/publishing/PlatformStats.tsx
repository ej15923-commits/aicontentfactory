
"use client";

import React from "react";
import { PublishingScheduleItem } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Facebook, Instagram, Twitter, Linkedin, Music, Youtube } from "lucide-react";

interface PlatformStatsProps {
  schedules: PublishingScheduleItem[];
}

const platformIcons = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  tiktok: Music,
  youtube: Youtube,
};

const platformColors = {
  facebook: "bg-blue-600",
  instagram: "bg-gradient-to-br from-purple-600 to-pink-600",
  twitter: "bg-sky-500",
  linkedin: "bg-blue-700",
  tiktok: "bg-black",
  youtube: "bg-red-600",
};

export default function PlatformStats({ schedules }: PlatformStatsProps) {
  const getPlatformStats = () => {
    const stats = schedules.reduce((acc, schedule) => {
      const platform = schedule.platform;
      if (!acc[platform]) {
        acc[platform] = {
          total: 0,
          scheduled: 0,
          published: 0,
          failed: 0,
        };
      }
      
      acc[platform].total++;
      acc[platform][schedule.status]++;
      
      return acc;
    }, {} as Record<string, any>);

    return Object.entries(stats).map(([platform, data]) => ({
      platform: platform as keyof typeof platformIcons,
      ...data,
    }));
  };

  const platformStats = getPlatformStats();
  const totalScheduled = schedules.filter(s => s.status === 'scheduled').length;
  const totalPublished = schedules.filter(s => s.status === 'published').length;
  const totalFailed = schedules.filter(s => s.status === 'failed').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Overall Stats */}
      <Card className="bg-gradient-to-br from-blue-900/20 to-indigo-900/20 border-blue-800/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-400">Total Scheduled</p>
              <p className="text-2xl font-bold text-blue-300">{totalScheduled}</p>
            </div>
            <div className="w-12 h-12 bg-blue-900/30 rounded-full flex items-center justify-center">
              <span className="text-blue-400 font-bold text-lg">📅</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-green-900/20 to-emerald-900/20 border-green-800/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-400">Published</p>
              <p className="text-2xl font-bold text-green-300">{totalPublished}</p>
            </div>
            <div className="w-12 h-12 bg-green-900/30 rounded-full flex items-center justify-center">
              <span className="text-green-400 font-bold text-lg">✅</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-red-900/20 to-rose-900/20 border-red-800/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-400">Failed</p>
              <p className="text-2xl font-bold text-red-300">{totalFailed}</p>
            </div>
            <div className="w-12 h-12 bg-red-900/30 rounded-full flex items-center justify-center">
              <span className="text-red-400 font-bold text-lg">❌</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-purple-900/20 to-violet-900/20 border-purple-800/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-400">Platforms</p>
              <p className="text-2xl font-bold text-purple-300">{platformStats.length}</p>
            </div>
            <div className="w-12 h-12 bg-purple-900/30 rounded-full flex items-center justify-center">
              <span className="text-purple-400 font-bold text-lg">🌐</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Platform-specific stats */}
      {platformStats.length > 0 && (
        <Card className="md:col-span-2 lg:col-span-4 bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-lg text-white">Platform Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {platformStats.map(({ platform, total, scheduled, published, failed }) => {
                const Icon = platformIcons[platform as keyof typeof platformIcons];
                const colorClass = platformColors[platform as keyof typeof platformColors];
                
                return (
                  <div key={platform} className="flex items-center space-x-3 p-3 bg-slate-700/30 rounded-lg border border-slate-600">
                    <div className={`p-2 rounded-lg ${colorClass} text-white flex-shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-white capitalize">{platform}</p>
                      <div className="flex space-x-2 mt-1">
                        <Badge variant="outline" className="text-xs border-slate-500 text-slate-300">
                          {scheduled} scheduled
                        </Badge>
                        {published > 0 && (
                          <Badge variant="outline" className="text-xs bg-green-900/20 text-green-400 border-green-600">
                            {published} published
                          </Badge>
                        )}
                        {failed > 0 && (
                          <Badge variant="outline" className="text-xs bg-red-900/20 text-red-400 border-red-600">
                            {failed} failed
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

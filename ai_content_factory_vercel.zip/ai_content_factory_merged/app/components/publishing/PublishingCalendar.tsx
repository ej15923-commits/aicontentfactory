
"use client";

import React, { useState } from "react";
import { PublishingScheduleItem, ContentItem } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Music,
  Youtube
} from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths } from "date-fns";

interface PublishingCalendarProps {
  schedules: PublishingScheduleItem[];
  content: ContentItem[];
  onScheduleClick: (schedule: PublishingScheduleItem) => void;
}

const platformIcons = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  tiktok: Music,
  youtube: Youtube,
};

const platformColors = {
  facebook: "bg-blue-500",
  instagram: "bg-gradient-to-r from-purple-500 to-pink-500",
  twitter: "bg-sky-500",
  linkedin: "bg-blue-600",
  tiktok: "bg-black",
  youtube: "bg-red-500",
};

export default function PublishingCalendar({ 
  schedules, 
  content, 
  onScheduleClick 
}: PublishingCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const goToPreviousMonth = () => {
    setCurrentDate(prev => subMonths(prev, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(prev => addMonths(prev, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const getSchedulesForDate = (date: Date): PublishingScheduleItem[] => {
    return schedules.filter(schedule => {
      const scheduleDate = new Date(schedule.scheduledTime || schedule.scheduled_time || '');
      return isSameDay(scheduleDate, date);
    });
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarDays = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Pad the calendar to start from Sunday
  const firstDayOfWeek = monthStart.getDay();
  const paddingDays = Array.from({ length: firstDayOfWeek }, (_, i) => {
    const date = new Date(monthStart);
    date.setDate(date.getDate() - (firstDayOfWeek - i));
    return date;
  });

  // Add days to complete the last week
  const lastDayOfWeek = monthEnd.getDay();
  const trailingDays = Array.from({ length: 6 - lastDayOfWeek }, (_, i) => {
    const date = new Date(monthEnd);
    date.setDate(date.getDate() + (i + 1));
    return date;
  });

  const allCalendarDays = [...paddingDays, ...calendarDays, ...trailingDays];
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5" />
            Publishing Calendar
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={goToPreviousMonth}
                className="p-2"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <h3 className="text-lg font-medium min-w-[200px] text-center">
                {format(currentDate, 'MMMM yyyy')}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={goToNextMonth}
                className="p-2"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1">
          {/* Weekday headers */}
          {weekDays.map(day => (
            <div key={day} className="p-2 text-center text-sm font-medium text-gray-600">
              {day}
            </div>
          ))}

          {/* Calendar days */}
          {allCalendarDays.map((date, index) => {
            const daySchedules = getSchedulesForDate(date);
            const isCurrentMonth = date.getMonth() === currentDate.getMonth();
            const isCurrentDay = isToday(date);
            
            return (
              <div
                key={index}
                className={`
                  min-h-[120px] p-1 border border-gray-100 
                  ${isCurrentMonth ? 'bg-white' : 'bg-gray-50'}
                  ${isCurrentDay ? 'ring-2 ring-blue-500 ring-opacity-50' : ''}
                  hover:bg-blue-50 transition-colors
                `}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`
                    text-sm
                    ${!isCurrentMonth ? 'text-gray-400' : isCurrentDay ? 'text-blue-600 font-bold' : 'text-gray-900'}
                  `}>
                    {format(date, 'd')}
                  </span>
                  {daySchedules.length > 0 && (
                    <Badge variant="secondary" className="text-xs px-1 py-0">
                      {daySchedules.length}
                    </Badge>
                  )}
                </div>

                <div className="space-y-1">
                  {daySchedules.slice(0, 3).map((schedule, scheduleIndex) => {
                    const PlatformIcon = platformIcons[schedule.platform];
                    const scheduleTime = new Date(schedule.scheduledTime || schedule.scheduled_time || '');
                    
                    return (
                      <div
                        key={schedule.id}
                        onClick={() => onScheduleClick(schedule)}
                        className="group cursor-pointer p-1 rounded text-xs bg-white border border-gray-200 hover:border-blue-300 hover:shadow-sm transition-all"
                      >
                        <div className="flex items-center gap-1">
                          <PlatformIcon className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate flex-1">
                            {format(scheduleTime, 'h:mm a')}
                          </span>
                        </div>
                        <div className="truncate text-gray-600 mt-0.5">
                          {schedule.postContent || 'Untitled'}
                        </div>
                        
                        {/* Status indicator */}
                        <div className="mt-1">
                          <div className={`
                            w-2 h-2 rounded-full inline-block
                            ${schedule.status === 'scheduled' ? 'bg-blue-400' : 
                              schedule.status === 'published' ? 'bg-green-400' : 
                              schedule.status === 'failed' ? 'bg-red-400' : 'bg-gray-400'}
                          `} />
                        </div>
                      </div>
                    );
                  })}
                  
                  {daySchedules.length > 3 && (
                    <div className="text-xs text-gray-500 text-center py-1">
                      +{daySchedules.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 mt-6 pt-4 border-t border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-400"></div>
            <span className="text-sm text-gray-600">Scheduled</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-400"></div>
            <span className="text-sm text-gray-600">Published</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-400"></div>
            <span className="text-sm text-gray-600">Failed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gray-400"></div>
            <span className="text-sm text-gray-600">Cancelled</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}


"use client";

import React, { useState, useEffect } from "react";
import { ContentItem, PublishingSchedule } from "@/entities/all";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Calendar,
  Clock,
  Send,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Music,
  Youtube,
  X,
  Plus,
  Settings,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { format } from "date-fns";
import toast from "react-hot-toast";
import { motion } from "framer-motion";
import PlatformConnectionModal from "./PlatformConnectionModal";

interface PublishingModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: ContentItem | null;
  onComplete: () => void;
}

const platforms = [
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'text-blue-600' },
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'text-pink-600' },
  { id: 'twitter', name: 'Twitter', icon: Twitter, color: 'text-sky-600' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'text-blue-700' },
  { id: 'tiktok', name: 'TikTok', icon: Music, color: 'text-black' },
  { id: 'youtube', name: 'YouTube', icon: Youtube, color: 'text-red-600' },
];

export default function PublishingModal({ 
  isOpen, 
  onClose, 
  content, 
  onComplete 
}: PublishingModalProps) {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [postContent, setPostContent] = useState("");
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [hashtagInput, setHashtagInput] = useState("");
  const [publishType, setPublishType] = useState<'now' | 'schedule'>('schedule');
  const [loading, setLoading] = useState(false);
  const [connectedPlatforms, setConnectedPlatforms] = useState<Set<string>>(new Set());
  const [showConnectionModal, setShowConnectionModal] = useState(false);

  useEffect(() => {
    if (isOpen && content) {
      // Initialize form with content data
      setPostContent(content.content.substring(0, 500)); // Truncate for social media
      setHashtags(content.tags || []);
      
      // Set default schedule time to 1 hour from now
      const defaultTime = new Date(Date.now() + 60 * 60 * 1000);
      setScheduledDate(format(defaultTime, 'yyyy-MM-dd'));
      setScheduledTime(format(defaultTime, 'HH:mm'));
      
      // Clear platform selection
      setSelectedPlatforms([]);
      setPublishType('schedule');
      
      // Load connected platforms
      loadConnectedPlatforms();
    }
  }, [isOpen, content]);

  const loadConnectedPlatforms = async () => {
    try {
      const response = await fetch('/api/platforms/connections');
      if (response.ok) {
        const connections = await response.json();
        const connected = new Set<string>(connections.map((conn: any) => conn.platform));
        setConnectedPlatforms(connected);
      }
    } catch (error) {
      console.error('Error loading connected platforms:', error);
    }
  };

  const handlePlatformToggle = (platformId: string) => {
    if (!connectedPlatforms.has(platformId)) {
      toast.error(`Please connect to ${platforms.find(p => p.id === platformId)?.name} first`);
      setShowConnectionModal(true);
      return;
    }
    
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
  };

  const handleAddHashtag = () => {
    if (hashtagInput.trim() && !hashtags.includes(hashtagInput.trim())) {
      const tag = hashtagInput.trim().startsWith('#') ? hashtagInput.trim() : `#${hashtagInput.trim()}`;
      setHashtags(prev => [...prev, tag]);
      setHashtagInput("");
    }
  };

  const handleRemoveHashtag = (tagToRemove: string) => {
    setHashtags(prev => prev.filter(tag => tag !== tagToRemove));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && hashtagInput.trim()) {
      e.preventDefault();
      handleAddHashtag();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content) return;
    if (selectedPlatforms.length === 0) {
      toast.error("Please select at least one platform");
      return;
    }
    if (!postContent.trim()) {
      toast.error("Please enter post content");
      return;
    }
    if (publishType === 'schedule' && (!scheduledDate || !scheduledTime)) {
      toast.error("Please select schedule date and time");
      return;
    }

    setLoading(true);
    
    try {
      const scheduleData = {
        contentId: content.id,
        postContent: postContent.trim(),
        hashtags: hashtags,
        scheduledTime: publishType === 'now' 
          ? new Date().toISOString()
          : new Date(`${scheduledDate}T${scheduledTime}`).toISOString(),
      };

      // Create schedule entries for each selected platform
      const schedulePromises = selectedPlatforms.map(platform => 
        PublishingSchedule.create({
          ...scheduleData,
          platform: platform as any,
          status: publishType === 'now' ? 'published' : 'scheduled',
          userId: 'current-user', // This should come from auth context
        })
      );

      await Promise.all(schedulePromises);

      toast.success(
        publishType === 'now' 
          ? `Published to ${selectedPlatforms.length} platform(s)!`
          : `Scheduled for ${selectedPlatforms.length} platform(s)!`
      );
      
      onComplete();
    } catch (error) {
      console.error('Publishing error:', error);
      toast.error("Failed to schedule posts. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getScheduledDateTime = () => {
    if (!scheduledDate || !scheduledTime) return null;
    return new Date(`${scheduledDate}T${scheduledTime}`);
  };

  if (!content) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Schedule Publication
          </DialogTitle>
          <DialogDescription>
            Choose platforms and schedule your content for publishing
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Content Preview */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-medium text-gray-900 mb-2">{content.title}</h3>
              <p className="text-sm text-gray-600 line-clamp-3">{content.content}</p>
            </CardContent>
          </Card>

          {/* Publish Type Selection */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Publication Type</Label>
            <div className="flex gap-4">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="publishType"
                  value="now"
                  checked={publishType === 'now'}
                  onChange={(e) => setPublishType(e.target.value as 'now')}
                  className="text-blue-600"
                />
                <span>Publish Now</span>
              </label>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="publishType"
                  value="schedule"
                  checked={publishType === 'schedule'}
                  onChange={(e) => setPublishType(e.target.value as 'schedule')}
                  className="text-blue-600"
                />
                <span>Schedule for Later</span>
              </label>
            </div>
          </div>

          {/* Schedule Date & Time */}
          {publishType === 'schedule' && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Date
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  min={format(new Date(), 'yyyy-MM-dd')}
                  required={publishType === 'schedule'}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time" className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Time
                </Label>
                <Input
                  id="time"
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  required={publishType === 'schedule'}
                />
              </div>
            </div>
          )}

          {/* Platform Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">Select Platforms</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowConnectionModal(true)}
                className="flex items-center gap-2"
              >
                <Settings className="w-4 h-4" />
                Manage Connections
              </Button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {platforms.map((platform) => {
                const Icon = platform.icon;
                const isSelected = selectedPlatforms.includes(platform.id);
                const isConnected = connectedPlatforms.has(platform.id);
                
                return (
                  <motion.div
                    key={platform.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div
                      onClick={() => handlePlatformToggle(platform.id)}
                      className={`
                        p-3 rounded-lg border-2 cursor-pointer transition-all relative
                        ${isSelected 
                          ? 'border-blue-500 bg-blue-50' 
                          : isConnected
                          ? 'border-gray-200 hover:border-gray-300'
                          : 'border-gray-200 bg-gray-50 opacity-60'
                        }
                      `}
                    >
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          checked={isSelected}
                          disabled={!isConnected}
                          onChange={() => handlePlatformToggle(platform.id)}
                        />
                        <Icon className={`w-5 h-5 ${platform.color}`} />
                        <span className={`font-medium ${!isConnected ? 'text-gray-400' : ''}`}>
                          {platform.name}
                        </span>
                        {isConnected ? (
                          <CheckCircle className="w-4 h-4 text-green-600 ml-auto" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-orange-500 ml-auto" />
                        )}
                      </div>
                      {!isConnected && (
                        <div className="text-xs text-gray-500 mt-1">Not connected</div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
            {connectedPlatforms.size === 0 && (
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-orange-800">
                        No platforms connected
                      </p>
                      <p className="text-xs text-orange-700 mt-1">
                        You need to connect at least one social media platform to schedule posts.
                      </p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowConnectionModal(true)}
                        className="mt-2 border-orange-300 text-orange-700 hover:bg-orange-100"
                      >
                        <Settings className="w-4 h-4 mr-1" />
                        Connect Platforms
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Post Content */}
          <div className="space-y-2">
            <Label htmlFor="postContent">Post Content</Label>
            <Textarea
              id="postContent"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder="Enter your post content..."
              rows={4}
              maxLength={500}
              required
            />
            <div className="text-xs text-gray-500 text-right">
              {postContent.length}/500 characters
            </div>
          </div>

          {/* Hashtags */}
          <div className="space-y-3">
            <Label>Hashtags</Label>
            <div className="flex gap-2">
              <Input
                value={hashtagInput}
                onChange={(e) => setHashtagInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Add hashtag..."
                className="flex-1"
              />
              <Button 
                type="button" 
                variant="outline"
                onClick={handleAddHashtag}
                disabled={!hashtagInput.trim()}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {hashtags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {hashtags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveHashtag(tag)}
                      className="ml-1 hover:text-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Summary */}
          {publishType === 'schedule' && scheduledDate && scheduledTime && (
            <Card>
              <CardContent className="p-4">
                <div className="text-sm text-gray-600">
                  <strong>Summary:</strong> Publishing to {selectedPlatforms.length} platform(s) on{' '}
                  {getScheduledDateTime() && format(getScheduledDateTime()!, 'EEEE, MMMM d, yyyy \'at\' h:mm a')}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={loading || selectedPlatforms.length === 0}
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Send className="w-4 h-4" />
                  {publishType === 'now' ? 'Publish Now' : 'Schedule Post'}
                </div>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
      
      {/* Platform Connection Modal */}
      <PlatformConnectionModal
        isOpen={showConnectionModal}
        onClose={() => setShowConnectionModal(false)}
        onConnectionUpdate={() => {
          loadConnectedPlatforms();
          setShowConnectionModal(false);
        }}
      />
    </Dialog>
  );
}


"use client";

import React from "react";
import { ContentItem } from "@/entities/all";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, Send, FileText, Video, Mail, MessageSquare, Calendar } from "lucide-react";
import { format } from "date-fns";

interface ContentSelectorProps {
  content: ContentItem[];
  filters: {
    query: string;
    platform: string;
    status: string;
    sort: string;
  };
  loading: boolean;
  onPublish: (content: ContentItem) => void;
}

const contentTypeIcons = {
  article: FileText,
  social_post: MessageSquare,
  video_script: Video,
  email: Mail,
};

const statusColors = {
  draft: "bg-yellow-900/20 text-yellow-400 border-yellow-600",
  approved: "bg-green-900/20 text-green-400 border-green-600",
  published: "bg-blue-900/20 text-blue-400 border-blue-600",
  archived: "bg-slate-700/20 text-slate-400 border-slate-600",
};

export default function ContentSelector({ 
  content, 
  filters, 
  loading, 
  onPublish 
}: ContentSelectorProps) {
  const getFilteredContent = () => {
    let filtered = content;

    // Filter by search query
    if (filters.query) {
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(filters.query.toLowerCase()) ||
        item.content.toLowerCase().includes(filters.query.toLowerCase()) ||
        item.tags?.some(tag => tag.toLowerCase().includes(filters.query.toLowerCase()))
      );
    }

    // Filter by status
    if (filters.status && filters.status !== 'all') {
      filtered = filtered.filter(item => item.status === filters.status);
    }

    // Sort
    filtered.sort((a, b) => {
      const field = filters.sort.startsWith('-') ? filters.sort.slice(1) : filters.sort;
      const direction = filters.sort.startsWith('-') ? -1 : 1;
      
      if (field === 'createdAt' || field === 'updatedAt') {
        return direction * (new Date(a[field]).getTime() - new Date(b[field]).getTime());
      }
      
      return direction * (a[field as keyof ContentItem]?.toString() || '').localeCompare(
        b[field as keyof ContentItem]?.toString() || ''
      );
    });

    return filtered;
  };

  const getWordCount = (content: string): number => {
    return content.trim().split(/\s+/).length;
  };

  const getReadingTime = (content: string): number => {
    const wordCount = getWordCount(content);
    return Math.ceil(wordCount / 200); // Average reading speed
  };

  if (loading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-slate-400">Loading content...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const filteredContent = getFilteredContent();

  return (
    <div className="space-y-4">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Eye className="w-5 h-5" />
            Content Library
          </CardTitle>
          <CardDescription className="text-slate-400">
            Browse and publish your approved content across platforms
          </CardDescription>
        </CardHeader>
      </Card>

      {filteredContent.length === 0 ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">No content found</h3>
            <p className="text-slate-400">
              {filters.query || filters.status !== 'all' 
                ? "No content matches your current filters" 
                : "Create your first piece of content to get started"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContent.map((item) => {
            const TypeIcon = contentTypeIcons[item.type] || FileText;
            const wordCount = getWordCount(item.content);
            const readingTime = getReadingTime(item.content);
            
            return (
              <Card key={item.id} className="group bg-slate-800/50 border-slate-700 hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-slate-700/50 rounded-lg">
                        <TypeIcon className="w-4 h-4 text-purple-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-white line-clamp-2 leading-tight">
                          {item.title}
                        </h3>
                      </div>
                    </div>
                    <Badge className={statusColors[item.status]}>
                      {item.status}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Content Preview */}
                  <div className="text-sm text-slate-400 line-clamp-3">
                    {item.content}
                  </div>

                  {/* Metadata */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="capitalize">{item.type.replace('_', ' ')}</span>
                      <span>{wordCount} words</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span>{readingTime} min read</span>
                      <span>{format(new Date(item.createdAt), 'MMM d')}</span>
                    </div>
                  </div>

                  {/* Tags */}
                  {item.tags && item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {item.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs px-2 py-1 border-slate-600 text-slate-400">
                          {tag}
                        </Badge>
                      ))}
                      {item.tags.length > 3 && (
                        <Badge variant="outline" className="text-xs px-2 py-1 border-slate-600 text-slate-400">
                          +{item.tags.length - 3}
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Additional metadata */}
                  {item.metadata && (
                    <div className="text-xs text-slate-500 space-y-1">
                      {item.metadata.targetAudience && (
                        <div>Target: {item.metadata.targetAudience}</div>
                      )}
                      {item.metadata.tone && (
                        <div>Tone: {item.metadata.tone}</div>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2 pt-2 border-t border-slate-700">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700/50"
                      onClick={() => {
                        // Preview functionality could be added here
                        console.log('Preview content:', item.id);
                      }}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Preview
                    </Button>
                    
                    {item.status === 'approved' && (
                      <Button
                        size="sm"
                        className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                        onClick={() => onPublish(item)}
                      >
                        <Send className="w-4 h-4 mr-1" />
                        Publish
                      </Button>
                    )}
                    
                    {item.status !== 'approved' && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 border-slate-600 text-slate-500"
                        disabled
                      >
                        <Calendar className="w-4 h-4 mr-1" />
                        {item.status === 'draft' ? 'Draft' : 
                         item.status === 'published' ? 'Published' : 
                         'Archived'}
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Summary Stats */}
      {filteredContent.length > 0 && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-400">
                  {filteredContent.length}
                </div>
                <div className="text-sm text-slate-400">Total Items</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-400">
                  {filteredContent.filter(c => c.status === 'approved').length}
                </div>
                <div className="text-sm text-slate-400">Ready to Publish</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-400">
                  {filteredContent.filter(c => c.status === 'draft').length}
                </div>
                <div className="text-sm text-slate-400">Drafts</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-400">
                  {filteredContent.filter(c => c.status === 'published').length}
                </div>
                <div className="text-sm text-slate-400">Published</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

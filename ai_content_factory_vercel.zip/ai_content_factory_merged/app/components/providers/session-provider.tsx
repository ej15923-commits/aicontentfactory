
"use client";

import { SessionProvider } from "next-auth/react";
import { ReactNode, useState, useEffect } from "react";

interface Props {
  children: ReactNode;
}

export default function Providers({ children }: Props) {
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  if (!hasMounted) {
    return <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 animate-pulse"></div>;
  }

  return (
    <SessionProvider>
      {children}
    </SessionProvider>
  );
}

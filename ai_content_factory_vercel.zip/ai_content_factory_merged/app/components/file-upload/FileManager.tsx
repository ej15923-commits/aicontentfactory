
"use client";

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  File, 
  Image, 
  FileText, 
  Video, 
  Music,
  Trash2,
  Download,
  Search,
  Grid,
  List,
  Calendar,
  Eye,
  Copy
} from 'lucide-react';
import toast from 'react-hot-toast';

interface FileInfo {
  id: string;
  name: string;
  originalName: string;
  size: number;
  type: string;
  url: string;
  uploadedAt: string;
}

interface FileManagerProps {
  onFileSelect?: (file: FileInfo) => void;
  selectable?: boolean;
  showUploadButton?: boolean;
  className?: string;
}

export function FileManager({ 
  onFileSelect, 
  selectable = false,
  showUploadButton = true,
  className = '' 
}: FileManagerProps) {
  const [files, setFiles] = useState<FileInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/files');
      if (response.ok) {
        const data = await response.json();
        setFiles(data);
      } else {
        toast.error('Failed to load files');
      }
    } catch (error) {
      console.error('Error fetching files:', error);
      toast.error('Failed to load files');
    } finally {
      setLoading(false);
    }
  };

  const deleteFile = async (fileName: string) => {
    if (!confirm('Are you sure you want to delete this file?')) {
      return;
    }

    try {
      const response = await fetch(`/api/files?filename=${fileName}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setFiles(files.filter(f => f.name !== fileName));
        toast.success('File deleted successfully');
      } else {
        toast.error('Failed to delete file');
      }
    } catch (error) {
      console.error('Error deleting file:', error);
      toast.error('Failed to delete file');
    }
  };

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(window.location.origin + url);
    toast.success('URL copied to clipboard');
  };

  const downloadFile = (file: FileInfo) => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.originalName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <Image className="w-5 h-5" />;
    if (type.startsWith('video/')) return <Video className="w-5 h-5" />;
    if (type.startsWith('audio/')) return <Music className="w-5 h-5" />;
    if (type === 'application/pdf' || type.startsWith('text/')) return <FileText className="w-5 h-5" />;
    return <File className="w-5 h-5" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const filteredFiles = files.filter(file =>
    file.originalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    file.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400 mx-auto"></div>
          <p className="text-slate-400 mt-2">Loading files...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`space-y-4 ${className}`}>
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white">File Manager</CardTitle>
              <CardDescription className="text-slate-400">
                {files.length} file{files.length !== 1 ? 's' : ''} uploaded
              </CardDescription>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
                className="bg-slate-700/50 border-slate-600 text-slate-400 hover:bg-slate-600/50"
              >
                {viewMode === 'grid' ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
              </Button>
              
              {showUploadButton && (
                <Button
                  onClick={fetchFiles}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Refresh
                </Button>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search files..."
                className="pl-10 bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {filteredFiles.length === 0 ? (
            <div className="text-center py-8">
              <File className="w-16 h-16 mx-auto mb-4 text-slate-400" />
              <h3 className="text-lg font-medium text-white mb-2">
                {searchQuery ? 'No files found' : 'No files uploaded'}
              </h3>
              <p className="text-slate-400">
                {searchQuery ? 'Try a different search term' : 'Upload your first file to get started'}
              </p>
            </div>
          ) : (
            <div className={viewMode === 'grid' ? 
              'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4' : 
              'space-y-2'
            }>
              {filteredFiles.map((file) => (
                <div
                  key={file.id}
                  className={`bg-slate-700/50 rounded-lg p-4 transition-colors ${
                    selectable ? 'cursor-pointer hover:bg-slate-600/50' : ''
                  } ${
                    selectedFiles.has(file.id) ? 'ring-2 ring-purple-400' : ''
                  }`}
                  onClick={() => {
                    if (selectable && onFileSelect) {
                      onFileSelect(file);
                    }
                  }}
                >
                  {viewMode === 'grid' ? (
                    <div>
                      <div className="flex items-center space-x-2 mb-3">
                        <div className="text-slate-400">
                          {getFileIcon(file.type)}
                        </div>
                        <span className="text-sm font-medium text-white truncate">
                          {file.originalName}
                        </span>
                      </div>

                      {file.type.startsWith('image/') && (
                        <div className="aspect-video bg-slate-600 rounded overflow-hidden mb-3">
                          <img 
                            src={file.url} 
                            alt={file.originalName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs text-slate-400">
                          <span>{formatFileSize(file.size)}</span>
                          <Badge variant="secondary" className="bg-slate-600/50 text-slate-300">
                            {file.type.split('/')[0]}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center text-xs text-slate-400">
                          <Calendar className="w-3 h-3 mr-1" />
                          {formatDate(file.uploadedAt)}
                        </div>

                        <div className="flex items-center space-x-1 pt-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              window.open(file.url, '_blank');
                            }}
                            className="h-7 px-2 text-xs text-slate-400 hover:text-white"
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            View
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              copyUrl(file.url);
                            }}
                            className="h-7 px-2 text-xs text-slate-400 hover:text-white"
                          >
                            <Copy className="w-3 h-3 mr-1" />
                            Copy
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              downloadFile(file);
                            }}
                            className="h-7 px-2 text-xs text-slate-400 hover:text-white"
                          >
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteFile(file.name);
                            }}
                            className="h-7 px-2 text-xs text-red-400 hover:text-red-300"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-3">
                      <div className="text-slate-400">
                        {getFileIcon(file.type)}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">
                          {file.originalName}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-slate-400">
                          <span>{formatFileSize(file.size)}</span>
                          <span>{formatDate(file.uploadedAt)}</span>
                          <Badge variant="secondary" className="bg-slate-600/50 text-slate-300">
                            {file.type.split('/')[0]}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            window.open(file.url, '_blank');
                          }}
                          className="h-7 w-7 p-0 text-slate-400 hover:text-white"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            copyUrl(file.url);
                          }}
                          className="h-7 w-7 p-0 text-slate-400 hover:text-white"
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            downloadFile(file);
                          }}
                          className="h-7 w-7 p-0 text-slate-400 hover:text-white"
                        >
                          <Download className="w-3 h-3" />
                        </Button>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteFile(file.name);
                          }}
                          className="h-7 w-7 p-0 text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

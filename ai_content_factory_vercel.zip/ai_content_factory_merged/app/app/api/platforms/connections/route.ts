
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// In-memory storage for demo purposes
// In a real app, this would be stored in a database
let platformConnections: Array<{
  platform: string;
  credentials: Record<string, string>;
  connectedAt: string;
  userId: string;
}> = [];

export async function GET(request: NextRequest) {
  try {
    // In a real app, you would filter by user ID from session
    const userId = 'current-user'; // This should come from session
    
    const userConnections = platformConnections
      .filter(conn => conn.userId === userId)
      .map(conn => ({
        platform: conn.platform,
        connectedAt: conn.connectedAt,
        // Don't return actual credentials for security
        hasCredentials: Object.keys(conn.credentials).length > 0
      }));

    return NextResponse.json(userConnections);
  } catch (error) {
    console.error('Error fetching platform connections:', error);
    return NextResponse.json(
      { error: 'Failed to fetch platform connections' },
      { status: 500 }
    );
  }
}

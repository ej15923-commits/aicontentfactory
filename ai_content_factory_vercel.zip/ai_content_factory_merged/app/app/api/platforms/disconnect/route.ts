
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// In-memory storage for demo purposes
// In a real app, this would be stored in a database
let platformConnections: Array<{
  platform: string;
  credentials: Record<string, string>;
  connectedAt: string;
  userId: string;
}> = [];

export async function POST(request: NextRequest) {
  try {
    const { platform } = await request.json();
    
    if (!platform) {
      return NextResponse.json(
        { error: 'Platform is required' },
        { status: 400 }
      );
    }

    // In a real app, you would get the user ID from session
    const userId = 'current-user';
    
    // Remove connection for this platform and user
    const initialLength = platformConnections.length;
    platformConnections = platformConnections.filter(
      conn => !(conn.platform === platform && conn.userId === userId)
    );
    
    if (platformConnections.length === initialLength) {
      return NextResponse.json(
        { error: `No connection found for ${platform}` },
        { status: 404 }
      );
    }

    console.log(`❌ Disconnected from ${platform} for user ${userId}`);
    
    return NextResponse.json({ 
      success: true, 
      message: `Successfully disconnected from ${platform}`
    });
  } catch (error) {
    console.error('Error disconnecting platform:', error);
    return NextResponse.json(
      { error: 'Failed to disconnect platform' },
      { status: 500 }
    );
  }
}

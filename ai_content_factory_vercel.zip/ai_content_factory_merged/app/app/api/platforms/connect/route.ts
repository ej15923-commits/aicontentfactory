
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// In-memory storage for demo purposes
// In a real app, this would be stored in a database with encryption
let platformConnections: Array<{
  platform: string;
  credentials: Record<string, string>;
  connectedAt: string;
  userId: string;
}> = [];

export async function POST(request: NextRequest) {
  try {
    const { platform, credentials } = await request.json();
    
    if (!platform || !credentials) {
      return NextResponse.json(
        { error: 'Platform and credentials are required' },
        { status: 400 }
      );
    }

    // In a real app, you would get the user ID from session
    const userId = 'current-user';
    
    // Validate credentials format based on platform
    const validationResult = validatePlatformCredentials(platform, credentials);
    if (!validationResult.isValid) {
      return NextResponse.json(
        { error: validationResult.error },
        { status: 400 }
      );
    }

    // Remove existing connection for this platform and user
    platformConnections = platformConnections.filter(
      conn => !(conn.platform === platform && conn.userId === userId)
    );
    
    // Add new connection
    platformConnections.push({
      platform,
      credentials,
      connectedAt: new Date().toISOString(),
      userId
    });

    console.log(`✅ Connected to ${platform} for user ${userId}`);
    
    return NextResponse.json({ 
      success: true, 
      message: `Successfully connected to ${platform}`,
      connectedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error connecting platform:', error);
    return NextResponse.json(
      { error: 'Failed to connect platform' },
      { status: 500 }
    );
  }
}

function validatePlatformCredentials(platform: string, credentials: Record<string, string>) {
  const requiredFields: Record<string, string[]> = {
    facebook: ['accessToken', 'pageId'],
    instagram: ['accessToken', 'userId'],
    twitter: ['apiKey', 'apiSecret', 'accessToken', 'accessTokenSecret'],
    linkedin: ['clientId', 'clientSecret', 'accessToken'],
    tiktok: ['clientKey', 'clientSecret', 'accessToken'],
    youtube: ['clientId', 'clientSecret', 'refreshToken']
  };

  const required = requiredFields[platform];
  if (!required) {
    return { isValid: false, error: `Unsupported platform: ${platform}` };
  }

  for (const field of required) {
    if (!credentials[field] || credentials[field].trim() === '') {
      return { isValid: false, error: `Missing required field: ${field}` };
    }
  }

  return { isValid: true };
}

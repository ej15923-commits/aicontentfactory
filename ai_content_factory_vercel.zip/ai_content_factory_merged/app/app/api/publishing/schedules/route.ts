
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const platform = searchParams.get('platform');
    const sort = searchParams.get('sort') || '-scheduledTime';

    let where: any = {
      userId: session.user.id
    };

    if (status) {
      where.status = status.toUpperCase();
    }

    if (platform && platform !== 'all') {
      where.platform = platform;
    }

    // Parse sort parameter
    let orderBy: any = {};
    if (sort.startsWith('-')) {
      const field = sort.slice(1);
      orderBy[field === 'scheduledTime' ? 'scheduledTime' : field] = 'desc';
    } else {
      orderBy[sort === 'scheduledTime' ? 'scheduledTime' : sort] = 'asc';
    }

    const schedules = await prisma.publishedContent.findMany({
      where,
      orderBy,
      include: {
        user: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    return NextResponse.json(schedules);
  } catch (error) {
    console.error("Error fetching schedules:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

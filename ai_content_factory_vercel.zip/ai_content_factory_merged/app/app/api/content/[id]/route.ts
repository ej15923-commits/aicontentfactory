
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const content = await prisma.generatedContent.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      },
      include: {
        project: true,
        user: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    if (!content) {
      return NextResponse.json({ error: "Content not found" }, { status: 404 });
    }

    return NextResponse.json(content);
  } catch (error) {
    console.error("Error fetching content:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const data = await request.json();

    const content = await prisma.generatedContent.updateMany({
      where: {
        id: params.id,
        userId: session.user.id
      },
      data
    });

    if (content.count === 0) {
      return NextResponse.json({ error: "Content not found" }, { status: 404 });
    }

    const updatedContent = await prisma.generatedContent.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      },
      include: {
        project: true,
        user: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    return NextResponse.json(updatedContent);
  } catch (error) {
    console.error("Error updating content:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const result = await prisma.generatedContent.deleteMany({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (result.count === 0) {
      return NextResponse.json({ error: "Content not found" }, { status: 404 });
    }

    return NextResponse.json({ message: "Content deleted successfully" });
  } catch (error) {
    console.error("Error deleting content:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

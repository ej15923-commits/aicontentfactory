

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { urls } = await req.json();

    if (!urls || !Array.isArray(urls)) {
      return NextResponse.json({ error: "URLs array is required" }, { status: 400 });
    }

    const results = [];

    for (const url of urls) {
      try {
        const scrapedData = await scrapeUrl(url);
        results.push({
          url,
          success: true,
          data: scrapedData
        });
      } catch (error) {
        results.push({
          url,
          success: false,
          error: error instanceof Error ? error.message : 'Scraping failed'
        });
      }
    }

    return NextResponse.json({ 
      success: true,
      results
    });

  } catch (error) {
    console.error("URL scraper error:", error);
    return NextResponse.json(
      { error: "Failed to scrape URLs" },
      { status: 500 }
    );
  }
}

async function scrapeUrl(url: string) {
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; AIContentFactory/1.0)'
    }
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  const html = await response.text();
  
  // Extract metadata
  const title = extractFromHtml(html, /<title>(.*?)<\/title>/i);
  const description = extractFromHtml(html, /<meta\s+name="description"\s+content="(.*?)"/i);
  const keywords = extractFromHtml(html, /<meta\s+name="keywords"\s+content="(.*?)"/i);
  const author = extractFromHtml(html, /<meta\s+name="author"\s+content="(.*?)"/i);
  
  // Extract Open Graph data
  const ogTitle = extractFromHtml(html, /<meta\s+property="og:title"\s+content="(.*?)"/i);
  const ogDescription = extractFromHtml(html, /<meta\s+property="og:description"\s+content="(.*?)"/i);
  const ogImage = extractFromHtml(html, /<meta\s+property="og:image"\s+content="(.*?)"/i);
  
  // Extract main content
  const textContent = html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
    .replace(/<nav\b[^<]*(?:(?!<\/nav>)<[^<]*)*<\/nav>/gi, '')
    .replace(/<header\b[^<]*(?:(?!<\/header>)<[^<]*)*<\/header>/gi, '')
    .replace(/<footer\b[^<]*(?:(?!<\/footer>)<[^<]*)*<\/footer>/gi, '')
    .replace(/<aside\b[^<]*(?:(?!<\/aside>)<[^<]*)*<\/aside>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Extract headings
  const headings = [];
  const h1Match = html.match(/<h1[^>]*>(.*?)<\/h1>/gi);
  const h2Match = html.match(/<h2[^>]*>(.*?)<\/h2>/gi);
  const h3Match = html.match(/<h3[^>]*>(.*?)<\/h3>/gi);
  
  if (h1Match) headings.push(...h1Match.map(h => h.replace(/<[^>]+>/g, '').trim()));
  if (h2Match) headings.push(...h2Match.map(h => h.replace(/<[^>]+>/g, '').trim()));
  if (h3Match) headings.push(...h3Match.map(h => h.replace(/<[^>]+>/g, '').trim()));

  // Extract images
  const imageMatches = html.match(/<img[^>]+src="([^"]+)"/gi);
  const images = imageMatches ? imageMatches.map(img => {
    const srcMatch = img.match(/src="([^"]+)"/);
    const altMatch = img.match(/alt="([^"]+)"/);
    return {
      src: srcMatch ? srcMatch[1] : '',
      alt: altMatch ? altMatch[1] : ''
    };
  }) : [];

  return {
    url,
    title: ogTitle || title || '',
    description: ogDescription || description || '',
    keywords: keywords || '',
    author: author || '',
    headings,
    images: images.slice(0, 5), // Limit to first 5 images
    content: textContent.substring(0, 3000), // Limit content length
    wordCount: textContent.split(/\s+/).length,
    scrapedAt: new Date().toISOString(),
    metadata: {
      ogTitle,
      ogDescription,
      ogImage,
      originalTitle: title,
      originalDescription: description
    }
  };
}

function extractFromHtml(html: string, regex: RegExp): string {
  const match = html.match(regex);
  return match ? match[1].trim() : '';
}


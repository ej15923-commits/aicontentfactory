

import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    // Trigger the background worker
    const response = await fetch(`${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/automation/background-worker`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    const data = await response.json();

    return NextResponse.json({ 
      success: true,
      message: "Background automation triggered successfully",
      result: data
    });

  } catch (error) {
    console.error("Failed to trigger background automation:", error);
    return NextResponse.json(
      { error: "Failed to trigger background automation" },
      { status: 500 }
    );
  }
}

// GET endpoint for manual trigger via URL
export async function GET(req: NextRequest) {
  return POST(req);
}



import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// In-memory storage for demo purposes
// In a real app, this would be stored in a database
let workflows: Array<{
  id: string;
  name: string;
  description: string;
  trigger: string;
  actions: string[];
  status: 'active' | 'inactive';
  lastRun?: string;
  createdAt: string;
  userId: string;
}> = [];

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userId = 'current-user';
    const workflow = workflows.find(w => w.id === params.id && w.userId === userId);
    
    if (!workflow) {
      return NextResponse.json(
        { error: 'Workflow not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(workflow);
  } catch (error) {
    console.error('Error fetching workflow:', error);
    return NextResponse.json(
      { error: 'Failed to fetch workflow' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userId = 'current-user';
    const updates = await request.json();
    
    const workflowIndex = workflows.findIndex(w => w.id === params.id && w.userId === userId);
    
    if (workflowIndex === -1) {
      return NextResponse.json(
        { error: 'Workflow not found' },
        { status: 404 }
      );
    }
    
    workflows[workflowIndex] = {
      ...workflows[workflowIndex],
      ...updates
    };
    
    if (updates.status) {
      console.log(`✅ Updated workflow ${params.id} status to: ${updates.status}`);
    }
    
    return NextResponse.json(workflows[workflowIndex]);
  } catch (error) {
    console.error('Error updating workflow:', error);
    return NextResponse.json(
      { error: 'Failed to update workflow' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userId = 'current-user';
    const workflowIndex = workflows.findIndex(w => w.id === params.id && w.userId === userId);
    
    if (workflowIndex === -1) {
      return NextResponse.json(
        { error: 'Workflow not found' },
        { status: 404 }
      );
    }
    
    const deletedWorkflow = workflows[workflowIndex];
    workflows.splice(workflowIndex, 1);
    
    console.log(`✅ Deleted workflow: ${deletedWorkflow.name}`);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting workflow:', error);
    return NextResponse.json(
      { error: 'Failed to delete workflow' },
      { status: 500 }
    );
  }
}

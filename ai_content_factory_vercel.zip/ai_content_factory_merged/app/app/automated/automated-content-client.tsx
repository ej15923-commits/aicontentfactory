
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import DropdownSuggestions from "@/components/ui/dropdown-suggestions";
import { CONTENT_NICHE_SUGGESTIONS, TARGET_AUDIENCE_SUGGESTIONS } from "@/lib/content-suggestions";
import { 
  ArrowLeft,
  Sparkles, 
  Bot,
  Calendar,
  Target,
  Settings,
  Play,
  Pause,
  RotateCcw,
  Zap,
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  BarChart3,
  Globe,
  Loader2
} from "lucide-react";

interface AutomatedContentClientProps {
  userId: string;
}

export default function AutomatedContentClient({ userId }: AutomatedContentClientProps) {
  const [automationEnabled, setAutomationEnabled] = useState(false);
  const [contentTypes, setContentTypes] = useState({
    socialPosts: true,
    blogPosts: false,
    emails: true,
    adCopy: false
  });
  const [frequency, setFrequency] = useState("daily");
  const [niche, setNiche] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [brandVoice, setBrandVoice] = useState("professional");
  const [isStarting, setIsStarting] = useState(false);
  const [isStopping, setIsStopping] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [targetUrl, setTargetUrl] = useState("");
  const [isProcessingUrl, setIsProcessingUrl] = useState(false);
  const [urlHistory, setUrlHistory] = useState<string[]>([]);
  const [isTriggeringBackground, setIsTriggeringBackground] = useState(false);
  const [affiliateLink, setAffiliateLink] = useState("");
  const [isRunningTest, setIsRunningTest] = useState(false);

  // Load automation status on component mount
  useEffect(() => {
    loadAutomationStatus();
    loadUrlHistory();
  }, []);

  const loadAutomationStatus = async () => {
    try {
      const response = await fetch('/api/automation/status');
      if (response.ok) {
        const data = await response.json();
        if (data.automation) {
          setAutomationEnabled(data.automation.isActive);
          setContentTypes(data.automation.contentTypes);
          setFrequency(data.automation.frequency);
          setNiche(data.automation.niche || "");
          setTargetAudience(data.automation.targetAudience || "");
          setBrandVoice(data.automation.brandVoice || "professional");
          setAffiliateLink(data.automation.affiliateLink || "");
        }
      }
    } catch (error) {
      console.error('Failed to load automation status:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUrlHistory = () => {
    const saved = localStorage.getItem('automation-url-history');
    if (saved) {
      setUrlHistory(JSON.parse(saved));
    }
  };

  const saveUrlToHistory = (url: string) => {
    const updated = [url, ...urlHistory.filter(u => u !== url)].slice(0, 10);
    setUrlHistory(updated);
    localStorage.setItem('automation-url-history', JSON.stringify(updated));
  };

  const automationStats = [
    { label: "Auto-Generated", value: 47, change: "+12%" },
    { label: "Auto-Published", value: 34, change: "+8" },
    { label: "Success Rate", value: "100%", change: "+6%" },
    { label: "Hours Saved", value: "47hrs", change: "+12hrs" }
  ];

  const automationHistory = [
    { 
      id: 1, 
      type: "Social Post", 
      title: "AI Marketing Trends from TechCrunch", 
      status: "published", 
      time: "2 hours ago",
      engagement: "124 likes, 23 comments",
      source: "techcrunch.com"
    },
    { 
      id: 2, 
      type: "Blog Post", 
      title: "Content Creation Insights from HubSpot", 
      status: "published", 
      time: "3 hours ago",
      engagement: "67 views, 12 shares",
      source: "blog.hubspot.com"
    },
    { 
      id: 3, 
      type: "Email", 
      title: "Weekly Newsletter from Entrepreneur.com", 
      status: "published", 
      time: "1 day ago",
      engagement: "89% open rate",
      source: "entrepreneur.com"
    }
  ];

  const handleStartAutomation = async () => {
    if (!niche.trim() || !targetAudience.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in your content niche and target audience.",
        variant: "destructive",
      });
      return;
    }

    setIsStarting(true);
    
    try {
      const response = await fetch('/api/automation/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          config: {
            contentTypes,
            frequency,
            niche,
            targetAudience,
            brandVoice,
            affiliateLink
          }
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setAutomationEnabled(true);
        toast({
          title: "Automation Started!",
          description: "Your content automation is now active.",
        });
      } else {
        throw new Error(data.error || 'Failed to start automation');
      }
    } catch (error) {
      console.error('Failed to start automation:', error);
      toast({
        title: "Failed to Start Automation",
        description: error instanceof Error ? error.message : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsStarting(false);
    }
  };

  const handleStopAutomation = async () => {
    setIsStopping(true);
    
    try {
      const response = await fetch('/api/automation/stop', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId }),
      });

      const data = await response.json();

      if (response.ok) {
        setAutomationEnabled(false);
        toast({
          title: "Automation Stopped",
          description: "Your content automation has been stopped.",
        });
      } else {
        throw new Error(data.error || 'Failed to stop automation');
      }
    } catch (error) {
      console.error('Failed to stop automation:', error);
      toast({
        title: "Failed to Stop Automation",
        description: error instanceof Error ? error.message : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsStopping(false);
    }
  };

  const handleToggleAutomation = async (checked: boolean) => {
    if (checked) {
      await handleStartAutomation();
    } else {
      await handleStopAutomation();
    }
  };

  const handleTestRun = async () => {
    if (!niche.trim() || !targetAudience.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in your content niche and target audience for the test run.",
        variant: "destructive",
      });
      return;
    }

    setIsRunningTest(true);
    
    try {
      const response = await fetch('/api/automation/test-run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          config: {
            contentTypes,
            frequency: 'test_run',
            niche,
            targetAudience,
            brandVoice,
            affiliateLink
          }
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Test Run Complete!",
          description: `Successfully generated ${data.generatedContent?.length || 1} piece(s) of test content. Check the publishing page to review.`,
        });
      } else {
        throw new Error(data.error || 'Failed to run test');
      }
    } catch (error) {
      console.error('Failed to run test:', error);
      toast({
        title: "Test Run Failed",
        description: error instanceof Error ? error.message : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsRunningTest(false);
    }
  };

  const handleProcessUrl = async () => {
    if (!targetUrl.trim()) {
      toast({
        title: "Missing URL",
        description: "Please enter a URL to process.",
        variant: "destructive",
      });
      return;
    }

    if (!automationEnabled) {
      toast({
        title: "Automation Not Active",
        description: "Please enable automation first.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessingUrl(true);

    try {
      // Get current automation config
      const statusResponse = await fetch('/api/automation/status');
      const statusData = await statusResponse.json();
      
      if (!statusData.automation) {
        throw new Error('No active automation configuration found');
      }

      // Process the URL through full automation
      const response = await fetch('/api/automation/full-process', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: targetUrl,
          automationId: statusData.automation.id,
          affiliateLink: affiliateLink || statusData.automation.affiliateLink
        }),
      });

      const data = await response.json();

      if (response.ok) {
        saveUrlToHistory(targetUrl);
        setTargetUrl("");
        
        toast({
          title: "Fully Automated Process Complete!",
          description: `Successfully processed ${targetUrl} and generated ${data.generatedContent.length} pieces of content. All content has been auto-approved and published!`,
        });
      } else {
        throw new Error(data.error || 'Failed to process URL');
      }
    } catch (error) {
      console.error('Failed to process URL:', error);
      toast({
        title: "Processing Failed",
        description: error instanceof Error ? error.message : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessingUrl(false);
    }
  };

  const handleTriggerBackground = async () => {
    if (!automationEnabled) {
      toast({
        title: "Automation Not Active",
        description: "Please enable automation first.",
        variant: "destructive",
      });
      return;
    }

    setIsTriggeringBackground(true);

    try {
      const response = await fetch('/api/automation/trigger-background', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Background Automation Triggered!",
          description: `Successfully processed ${data.result?.processed || 0} automations. Check the recent content below.`,
        });
      } else {
        throw new Error(data.error || 'Failed to trigger background automation');
      }
    } catch (error) {
      console.error('Failed to trigger background automation:', error);
      toast({
        title: "Background Trigger Failed",
        description: error instanceof Error ? error.message : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsTriggeringBackground(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-400" />
          <p className="text-slate-400">Loading automation settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800/30 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="w-px h-6 bg-slate-600" />
            <div>
              <h1 className="text-2xl font-semibold text-white">100% Automated AI Content Factory</h1>
              <p className="text-slate-400">Zero manual work: URL → Scrape → Generate → Approve → Publish</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className={`w-3 h-3 rounded-full ${automationEnabled ? 'bg-green-500' : 'bg-slate-500'}`} />
            <span className="text-sm text-slate-400">
              {automationEnabled ? 'Automation Active' : 'Automation Inactive'}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {automationStats.map((stat, index) => (
            <Card key={index} className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-2">
                <CardDescription className="text-slate-400">{stat.label}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <p className="text-sm text-green-400 mt-1">{stat.change}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Automation Configuration */}
          <div className="space-y-6">
            {/* URL Processing Section */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Globe className="w-5 h-5 mr-2 text-green-400" />
                  Instant Content Generation
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Enter any URL to instantly generate content from it (100% automated)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Input
                    placeholder="https://example.com/article-to-convert"
                    value={targetUrl}
                    onChange={(e) => setTargetUrl(e.target.value)}
                    disabled={!automationEnabled || isProcessingUrl}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-green-500 focus:ring-green-500/20"
                  />
                  <Button
                    onClick={handleProcessUrl}
                    disabled={!automationEnabled || isProcessingUrl || !targetUrl.trim()}
                    className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 whitespace-nowrap"
                  >
                    {isProcessingUrl ? (
                      <div className="flex items-center space-x-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Processing...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <Sparkles className="w-4 h-4" />
                        <span>Generate All</span>
                      </div>
                    )}
                  </Button>
                </div>

                {/* URL History */}
                {urlHistory.length > 0 && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Recent URLs
                    </label>
                    <div className="space-y-1">
                      {urlHistory.slice(0, 3).map((url, index) => (
                        <button
                          key={index}
                          onClick={() => setTargetUrl(url)}
                          disabled={!automationEnabled || isProcessingUrl}
                          className="w-full text-left px-3 py-2 bg-slate-700/30 rounded-md hover:bg-slate-700/50 text-slate-300 text-sm truncate disabled:opacity-50"
                        >
                          {url}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="p-4 bg-green-900/20 border border-green-700/50 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
                    <div>
                      <p className="text-green-200 font-medium">100% Automated Process</p>
                      <p className="text-green-300 text-sm">
                        URL → Scraping → Content Generation → Auto-Approval → Scheduling → Publishing
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Affiliate Link Configuration */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Target className="w-5 h-5 mr-2 text-orange-400" />
                  Affiliate Link Integration
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Add your affiliate link to be embedded in all generated content
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Affiliate Link (Optional)
                  </label>
                  <Input
                    placeholder="https://yoursite.com/affiliate?ref=your-id"
                    value={affiliateLink}
                    onChange={(e) => setAffiliateLink(e.target.value)}
                    disabled={automationEnabled}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-orange-500 focus:ring-orange-500/20"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    This link will be automatically embedded in all generated content where appropriate
                  </p>
                </div>

                <div className="p-3 bg-orange-900/20 border border-orange-700/50 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <Target className="w-4 h-4 text-orange-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-orange-200 font-medium text-sm">Smart Integration</p>
                      <p className="text-orange-300 text-xs">
                        The affiliate link will be contextually embedded in content as "Learn more", call-to-action buttons, or reference links
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Bot className="w-5 h-5 mr-2 text-blue-400" />
                  Full Automation Settings
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Configure 100% automated content pipeline - no manual approval needed
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Master Toggle */}
                <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Enable Full Automation</p>
                    <p className="text-sm text-slate-400">Auto-generate, approve, schedule and publish content</p>
                  </div>
                  <Switch 
                    checked={automationEnabled} 
                    onCheckedChange={handleToggleAutomation}
                    disabled={isStarting || isStopping || isLoading}
                  />
                </div>

                {/* Content Types */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-3">
                    Content Types to Generate
                  </label>
                  <div className="space-y-3">
                    {[
                      { key: 'socialPosts', label: 'Social Media Posts', icon: Target },
                      { key: 'blogPosts', label: 'Blog Posts', icon: BarChart3 },
                      { key: 'emails', label: 'Email Content', icon: Clock },
                      { key: 'adCopy', label: 'Ad Copy', icon: Zap }
                    ].map(({ key, label, icon: Icon }) => (
                      <div key={key} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Icon className="w-4 h-4 text-purple-400" />
                          <span className="text-white">{label}</span>
                        </div>
                        <Switch 
                          checked={contentTypes[key as keyof typeof contentTypes]} 
                          onCheckedChange={(checked) => 
                            setContentTypes(prev => ({ ...prev, [key]: checked }))
                          }
                          disabled={automationEnabled}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Frequency */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Generation Frequency
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value)}
                    disabled={automationEnabled}
                    className="w-full h-9 rounded-md border border-slate-600 bg-slate-700/50 px-3 py-1 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500/20 disabled:opacity-50"
                  >
                    <option value="test_run">Test Run (Single Content)</option>
                    <option value="hourly">Every Hour</option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                  {frequency === 'test_run' && (
                    <div className="mt-2 p-3 bg-blue-900/20 border border-blue-700/50 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Zap className="w-4 h-4 text-blue-400 mt-0.5" />
                        <div>
                          <p className="text-blue-200 font-medium text-sm">Test Run Mode</p>
                          <p className="text-blue-300 text-xs">
                            This will generate one piece of content immediately for testing purposes. Perfect for validating your automation settings.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Niche/Topic */}
                <DropdownSuggestions
                  label="Content Niche/Topic"
                  value={niche}
                  onChange={setNiche}
                  placeholder="e.g., AI technology, digital marketing, healthcare..."
                  suggestions={CONTENT_NICHE_SUGGESTIONS}
                  disabled={automationEnabled}
                />

                {/* Target Audience */}
                <DropdownSuggestions
                  label="Target Audience"
                  value={targetAudience}
                  onChange={setTargetAudience}
                  placeholder="e.g., tech professionals, small business owners..."
                  suggestions={TARGET_AUDIENCE_SUGGESTIONS}
                  disabled={automationEnabled}
                />

                {/* Brand Voice */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Brand Voice
                  </label>
                  <select
                    value={brandVoice}
                    onChange={(e) => setBrandVoice(e.target.value)}
                    disabled={automationEnabled}
                    className="w-full h-9 rounded-md border border-slate-600 bg-slate-700/50 px-3 py-1 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500/20 disabled:opacity-50"
                  >
                    <option value="professional">Professional</option>
                    <option value="casual">Casual</option>
                    <option value="friendly">Friendly</option>
                    <option value="authoritative">Authoritative</option>
                    <option value="humorous">Humorous</option>
                  </select>
                </div>

                {/* Control Buttons */}
                <div className="pt-4">
                  {frequency === 'test_run' ? (
                    <Button
                      onClick={handleTestRun}
                      disabled={isRunningTest || !niche.trim() || !targetAudience.trim()}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium py-3"
                    >
                      {isRunningTest ? (
                        <div className="flex items-center space-x-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Running Test...</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <Zap className="w-4 h-4" />
                          <span>Run Test (Generate Sample Content)</span>
                        </div>
                      )}
                    </Button>
                  ) : !automationEnabled ? (
                    <Button
                      onClick={handleStartAutomation}
                      disabled={isStarting || !niche.trim() || !targetAudience.trim()}
                      className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-medium py-3"
                    >
                      {isStarting ? (
                        <div className="flex items-center space-x-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Starting Automation...</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <Play className="w-4 h-4" />
                          <span>Start 100% Automation</span>
                        </div>
                      )}
                    </Button>
                  ) : (
                    <div className="space-y-3">
                      <Button
                        onClick={handleStopAutomation}
                        disabled={isStopping}
                        variant="destructive"
                        className="w-full"
                      >
                        {isStopping ? (
                          <div className="flex items-center space-x-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Stopping...</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-2">
                            <Pause className="w-4 h-4" />
                            <span>Stop Automation</span>
                          </div>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full border-slate-600 text-slate-300 hover:bg-slate-700/50"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Restart Automation
                      </Button>
                    </div>
                  )}
                </div>

                {/* Background Automation Trigger */}
                <div className="pt-4 border-t border-slate-600">
                  <Button
                    onClick={handleTriggerBackground}
                    disabled={!automationEnabled || isTriggeringBackground}
                    variant="outline"
                    className="w-full border-purple-600 text-purple-300 hover:bg-purple-600 hover:text-white"
                  >
                    {isTriggeringBackground ? (
                      <div className="flex items-center space-x-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Triggering Background...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <RotateCcw className="w-4 h-4" />
                        <span>Trigger Background Automation</span>
                      </div>
                    )}
                  </Button>
                  <p className="text-xs text-slate-400 mt-2 text-center">
                    Process all active automations with predefined URLs
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Automation History & Status */}
          <div className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-green-400" />
                  Recent Automated Content
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Content generated by your automation workflows
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {automationHistory.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <div className={`w-2 h-2 rounded-full ${
                            item.status === 'published' ? 'bg-green-500' : 
                            item.status === 'scheduled' ? 'bg-yellow-500' : 'bg-slate-500'
                          }`} />
                          <span className="text-sm text-slate-400">{item.type}</span>
                        </div>
                        <p className="font-medium text-white mb-1">{item.title}</p>
                        <div className="flex items-center space-x-4 text-sm text-slate-400 mb-2">
                          <span className="flex items-center space-x-1">
                            <Globe className="w-3 h-3" />
                            <span>Auto-generated from {item.source || 'unknown source'}</span>
                          </span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-slate-400">
                          <span className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{item.time}</span>
                          </span>
                          {item.engagement && (
                            <span className="flex items-center space-x-1">
                              <TrendingUp className="w-3 h-3" />
                              <span>{item.engagement}</span>
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {item.status === 'published' ? (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        ) : item.status === 'scheduled' ? (
                          <Clock className="w-5 h-5 text-yellow-500" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-red-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  <Link href="/publishing">
                    <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700/50">
                      <Globe className="w-4 h-4 mr-2" />
                      View Published
                    </Button>
                  </Link>
                  <Link href="/dashboard">
                    <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700/50">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Analytics
                    </Button>
                  </Link>
                  <Link href="/settings">
                    <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700/50">
                      <Settings className="w-4 h-4 mr-2" />
                      Advanced Settings
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    className="border-slate-600 text-slate-300 hover:bg-slate-700/50"
                    onClick={() => {/* TODO: Implement schedule modal */}}
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

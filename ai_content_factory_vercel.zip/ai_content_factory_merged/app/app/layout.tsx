
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Providers from "@/components/providers/session-provider";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "AI Content Factory",
  description: "Unlock your brand's potential with AI-powered content creation and publishing. Seamlessly generate, manage, and distribute high-quality videos, images, and text across social media platforms.",
  keywords: ["AI", "content creation", "social media", "marketing", "automation", "content factory"],
  openGraph: {
    title: "AI Content Factory",
    description: "AI-powered content creation and publishing platform",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={inter.className}>
        <Providers>
          <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
            {children}
          </div>
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}


"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowLeft,
  Search,
  FileText, 
  Target, 
  Zap, 
  Filter,
  Play,
  Copy,
  Star
} from "lucide-react";

interface Template {
  id: string;
  name: string;
  description: string | null;
  category: string;
  contentType: string;
  prompt: string;
  variables: any;
  isPublic: boolean;
  createdAt: Date;
}

interface TemplatesClientProps {
  templates: Template[];
}

export default function TemplatesClient({ templates }: TemplatesClientProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedContentType, setSelectedContentType] = useState("all");

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'SOCIAL_POST': return <Target className="w-5 h-5" />;
      case 'BLOG_POST': return <FileText className="w-5 h-5" />;
      case 'EMAIL': return <FileText className="w-5 h-5" />;
      case 'AD_COPY': return <Zap className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  const getContentTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'SOCIAL_POST': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'BLOG_POST': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'EMAIL': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'AD_COPY': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'VIDEO': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  // Get unique categories and content types
  const categories = Array.from(new Set(templates?.map(t => t?.category) || []));
  const contentTypes = Array.from(new Set(templates?.map(t => t?.contentType) || []));

  const filteredTemplates = templates?.filter(template => {
    const matchesSearch = template?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase() || '') ||
                         template?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase() || '') ||
                         template?.category?.toLowerCase()?.includes(searchQuery?.toLowerCase() || '');
    
    const matchesCategory = selectedCategory === 'all' || template?.category === selectedCategory;
    const matchesContentType = selectedContentType === 'all' || template?.contentType === selectedContentType;
    
    return matchesSearch && matchesCategory && matchesContentType;
  }) || [];

  const handleUseTemplate = (templateId: string) => {
    // Navigate to create page with template pre-selected
    window.location.href = `/create?template=${templateId}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800/30 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="w-px h-6 bg-slate-600" />
            <div>
              <h1 className="text-2xl font-semibold text-white">Content Templates</h1>
              <p className="text-slate-400">Browse and use proven templates for your content</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 rounded-md border border-slate-600 bg-slate-800/50 text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500/20"
            >
              <option value="all">All Categories</option>
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
            
            <select
              value={selectedContentType}
              onChange={(e) => setSelectedContentType(e.target.value)}
              className="px-4 py-2 rounded-md border border-slate-600 bg-slate-800/50 text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500/20"
            >
              <option value="all">All Types</option>
              {contentTypes.map(type => (
                <option key={type} value={type}>{type.replace('_', ' ')}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Templates Grid */}
        {filteredTemplates?.length > 0 ? (
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-all duration-300 group">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-gradient-to-r from-purple-600/20 to-blue-600/20">
                        {getContentTypeIcon(template.contentType)}
                      </div>
                      <div>
                        <CardTitle className="text-white group-hover:text-purple-300 transition-colors text-lg">
                          {template.name}
                        </CardTitle>
                        <div className="flex items-center space-x-2 mt-1">
                          <div className={`px-2 py-1 rounded-full text-xs border ${getContentTypeBadgeColor(template.contentType)}`}>
                            {template.contentType.replace('_', ' ')}
                          </div>
                          <span className="text-xs text-slate-500">{template.category}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <CardDescription className="text-slate-400 line-clamp-2">
                    {template.description || 'A powerful template for creating engaging content'}
                  </CardDescription>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    {/* Template Variables */}
                    {template.variables && typeof template.variables === 'object' && Object.keys(template.variables).length > 0 && (
                      <div>
                        <p className="text-xs text-slate-500 mb-2">Required variables:</p>
                        <div className="flex flex-wrap gap-1">
                          {Object.keys(template.variables).slice(0, 3).map((variable) => (
                            <span key={variable} className="px-2 py-1 bg-slate-700/50 rounded text-xs text-slate-300">
                              {variable}
                            </span>
                          ))}
                          {Object.keys(template.variables).length > 3 && (
                            <span className="px-2 py-1 bg-slate-700/50 rounded text-xs text-slate-400">
                              +{Object.keys(template.variables).length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Template Preview */}
                    <div className="bg-slate-700/30 rounded-lg p-3">
                      <p className="text-xs text-slate-400 mb-1">Template prompt:</p>
                      <p className="text-sm text-slate-300 line-clamp-3">
                        {template.prompt}
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex space-x-2">
                      <Link href={`/create?template=${template.id}`} className="flex-1">
                        <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
                          <Play className="w-4 h-4 mr-2" />
                          Use Template
                        </Button>
                      </Link>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-slate-400 hover:text-white hover:bg-slate-700/50"
                        onClick={() => navigator.clipboard?.writeText(template.prompt)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="py-16">
              <div className="text-center">
                <Target className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                <h3 className="text-xl font-semibold text-white mb-2">
                  {searchQuery || selectedCategory !== 'all' || selectedContentType !== 'all' 
                    ? 'No matching templates' 
                    : 'No templates available'
                  }
                </h3>
                <p className="text-slate-400 max-w-md mx-auto mb-6">
                  {searchQuery || selectedCategory !== 'all' || selectedContentType !== 'all'
                    ? 'Try adjusting your search or filter criteria'
                    : 'Templates are being loaded'
                  }
                </p>
                {(searchQuery || selectedCategory !== 'all' || selectedContentType !== 'all') && (
                  <Button 
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                      setSelectedContentType('all');
                    }}
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-800"
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

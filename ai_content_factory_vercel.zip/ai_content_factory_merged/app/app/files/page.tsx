
import { FilesClient } from './files-client';

export default function FilesPage() {
  return <FilesClient />;
}

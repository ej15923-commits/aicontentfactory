
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileUploader } from '@/components/file-upload/FileUploader';
import { FileManager } from '@/components/file-upload/FileManager';
import { ArrowLeft, Upload, FolderOpen, HardDrive, Image, FileText } from 'lucide-react';
import Link from 'next/link';

export function FilesClient() {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleUploadComplete = (files: any[]) => {
    console.log('Upload completed:', files);
    // Refresh the file manager to show new files
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto">
        {/* Back to Dashboard Button */}
        <div className="mb-6 pt-6 px-6">
          <Link href="/dashboard">
            <Button 
              variant="ghost" 
              className="text-white hover:bg-white/10 transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        <div className="flex justify-between items-center mb-8 px-6">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">File Manager</h1>
            <p className="text-slate-400">Upload, manage, and organize your files</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8 px-6">
          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Files</CardTitle>
              <HardDrive className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-slate-400">Files uploaded</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Images</CardTitle>
              <Image className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-slate-400">Image files</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Documents</CardTitle>
              <FileText className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-slate-400">Text & PDF files</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Storage Used</CardTitle>
              <FolderOpen className="h-4 w-4 text-orange-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0 MB</div>
              <p className="text-xs text-slate-400">Of unlimited</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="px-6">
          <Tabs defaultValue="upload" className="space-y-6">
            <TabsList className="bg-slate-800/50 border-slate-700">
              <TabsTrigger value="upload" className="data-[state=active]:bg-purple-600">
                <Upload className="w-4 h-4 mr-2" />
                Upload Files
              </TabsTrigger>
              <TabsTrigger value="manage" className="data-[state=active]:bg-purple-600">
                <FolderOpen className="w-4 h-4 mr-2" />
                Manage Files
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-6">
              <Card className="bg-slate-800/50 border-slate-700 text-white">
                <CardHeader>
                  <CardTitle>Upload New Files</CardTitle>
                  <CardDescription className="text-slate-400">
                    Drag and drop files or click to browse. Supports images, documents, and text files up to 10MB each.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <FileUploader
                    onUploadComplete={handleUploadComplete}
                    maxFiles={10}
                    multiple={true}
                    showPreview={true}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="manage" className="space-y-6">
              <FileManager 
                key={refreshKey}
                showUploadButton={true}
                selectable={false}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

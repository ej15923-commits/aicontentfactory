
"use client";

import React, { useState, useEffect } from "react";
import { Content, PublishingSchedule, ContentItem, PublishingScheduleItem } from "@/entities/all";
import { Calendar, Clock, Send, Eye, Filter, Search, Globe, PlayCircle, ArrowLeft, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PublishingQueue from "../../components/publishing/PublishingQueue";
import ContentSelector from "../../components/publishing/ContentSelector";
import PublishingModal from "../../components/publishing/PublishingModal";
import PlatformConnectionModal from "../../components/publishing/PlatformConnectionModal";
import PlatformStats from "../../components/publishing/PlatformStats";
import PublishingCalendar from "../../components/publishing/PublishingCalendar";
import { AnimatePresence } from "framer-motion";
import Link from "next/link";

interface PublishingClientProps {
  userId: string;
}

export default function PublishingClient({ userId }: PublishingClientProps) {
  const [content, setContent] = useState<ContentItem[]>([]);
  const [schedules, setSchedules] = useState<PublishingScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedContent, setSelectedContent] = useState<ContentItem | null>(null);
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [showConnectionModal, setShowConnectionModal] = useState(false);
  const [activeView, setActiveView] = useState("queue"); // queue, calendar, content
  const [filters, setFilters] = useState({
    query: "",
    platform: "all",
    status: "all",
    sort: "-created_date"
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [contentData, scheduleData] = await Promise.all([
        Content.filter({ status: "approved" }, "-createdAt"),
        PublishingSchedule.list("-scheduledTime")
      ]);
      
      setContent(contentData);
      setSchedules(scheduleData);
    } catch (error) {
      console.error("Error loading publishing data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handlePublishContent = (contentItem: ContentItem | null) => {
    setSelectedContent(contentItem);
    setShowPublishModal(true);
  };

  const handleScheduleComplete = () => {
    setShowPublishModal(false);
    setSelectedContent(null);
    loadData();
  };

  const handleStatusChange = async (scheduleId: string, newStatus: string) => {
    try {
      const schedule = schedules.find(s => s.id === scheduleId);
      if (schedule) {
        await PublishingSchedule.update(scheduleId, { ...schedule, status: newStatus as any });
        loadData();
      }
    } catch (error) {
      console.error("Error updating schedule status:", error);
    }
  };

  const handleDeleteSchedule = async (scheduleId: string) => {
    try {
      await PublishingSchedule.delete(scheduleId);
      loadData();
    } catch (error) {
      console.error("Error deleting schedule:", error);
      alert("Failed to delete scheduled post. Please try again.");
    }
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-4 mb-2">
                <Link href="/dashboard">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-slate-400 hover:text-white hover:bg-slate-700/50 -ml-2"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Dashboard
                  </Button>
                </Link>
              </div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                <Globe className="text-purple-400" />
                Publishing Center
              </h1>
              <p className="text-slate-400 mt-1">Schedule and publish content across all platforms.</p>
            </div>
            <div className="flex gap-3">
              <Button 
                onClick={() => setShowConnectionModal(true)}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700/50"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Manage Platforms
              </Button>
              <Button 
                onClick={() => handlePublishContent(null)}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg text-white"
              >
                <Send className="w-4 h-4 mr-2" />
                Schedule Post
              </Button>
            </div>
          </div>

          {/* Platform Stats */}
          <PlatformStats schedules={schedules} />

          {/* View Tabs */}
          <div className="bg-slate-800/50 backdrop-blur-xl border-slate-700 p-4 rounded-xl shadow-lg">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <Tabs value={activeView} onValueChange={setActiveView}>
                <TabsList className="grid w-full grid-cols-3 bg-slate-700/50 border-slate-600">
                  <TabsTrigger 
                    value="queue" 
                    className="flex items-center gap-2 text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                    onClick={() => setActiveView("queue")}
                  >
                    <Clock className="w-4 h-4" />
                    Queue
                  </TabsTrigger>
                  <TabsTrigger 
                    value="calendar" 
                    className="flex items-center gap-2 text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                    onClick={() => setActiveView("calendar")}
                  >
                    <Calendar className="w-4 h-4" />
                    Calendar
                  </TabsTrigger>
                  <TabsTrigger 
                    value="content" 
                    className="flex items-center gap-2 text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                    onClick={() => setActiveView("content")}
                  >
                    <Eye className="w-4 h-4" />
                    Content
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              {/* Filters */}
              <div className="flex gap-3 items-center">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input 
                    placeholder="Search..." 
                    className="pl-9 w-64 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                    value={filters.query}
                    onChange={(e) => setFilters(prev => ({ ...prev, query: e.target.value }))}
                  />
                </div>
                <Tabs 
                  value={filters.platform} 
                  onValueChange={(value) => setFilters(prev => ({ ...prev, platform: value }))}
                >
                  <TabsList className="bg-slate-700/50 border-slate-600">
                    <TabsTrigger 
                      value="all"
                      className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                      onClick={() => setFilters(prev => ({ ...prev, platform: "all" }))}
                    >
                      All Platforms
                    </TabsTrigger>
                    <TabsTrigger 
                      value="facebook"
                      className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                      onClick={() => setFilters(prev => ({ ...prev, platform: "facebook" }))}
                    >
                      Facebook
                    </TabsTrigger>
                    <TabsTrigger 
                      value="instagram"
                      className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                      onClick={() => setFilters(prev => ({ ...prev, platform: "instagram" }))}
                    >
                      Instagram
                    </TabsTrigger>
                    <TabsTrigger 
                      value="tiktok"
                      className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-purple-600"
                      onClick={() => setFilters(prev => ({ ...prev, platform: "tiktok" }))}
                    >
                      TikTok
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="space-y-6">
            {activeView === "queue" && (
              <PublishingQueue 
                schedules={schedules}
                content={content}
                filters={filters}
                loading={loading}
                onStatusChange={handleStatusChange}
                onDelete={handleDeleteSchedule}
                onEdit={(schedule: PublishingScheduleItem) => {
                  const contentItem = content.find(c => c.id === schedule.content_id || c.id === schedule.contentId);
                  if (contentItem) handlePublishContent(contentItem);
                }}
              />
            )}

            {activeView === "calendar" && (
              <PublishingCalendar 
                schedules={schedules}
                content={content}
                onScheduleClick={(schedule: PublishingScheduleItem) => {
                  const contentItem = content.find(c => c.id === schedule.content_id || c.id === schedule.contentId);
                  if (contentItem) handlePublishContent(contentItem);
                }}
              />
            )}

            {activeView === "content" && (
              <ContentSelector 
                content={content}
                filters={filters}
                loading={loading}
                onPublish={handlePublishContent}
              />
            )}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showPublishModal && (
          <PublishingModal
            isOpen={showPublishModal}
            onClose={() => setShowPublishModal(false)}
            content={selectedContent}
            onComplete={handleScheduleComplete}
          />
        )}
      </AnimatePresence>

      <PlatformConnectionModal
        isOpen={showConnectionModal}
        onClose={() => setShowConnectionModal(false)}
        onConnectionUpdate={() => loadData()}
      />
    </>
  );
}

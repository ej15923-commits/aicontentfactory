
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import ProjectsClient from "./projects-client";

export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect("/auth/signin");
  }

  // Fetch user projects with content count
  const projects = await prisma.contentProject.findMany({
    where: { userId: session.user.id },
    include: { 
      _count: { select: { generatedContent: true } },
      generatedContent: {
        select: {
          id: true,
          title: true,
          contentType: true,
          createdAt: true,
          content: true
        },
        orderBy: { createdAt: 'desc' },
        take: 3
      }
    },
    orderBy: { updatedAt: 'desc' }
  });

  return <ProjectsClient projects={projects || []} userId={session.user.id} />;
}

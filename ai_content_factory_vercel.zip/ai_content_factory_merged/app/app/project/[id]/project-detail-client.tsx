
"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowLeft,
  FileText, 
  Target, 
  Zap, 
  Calendar,
  User,
  Plus,
  Copy,
  Download,
  Share,
  Edit
} from "lucide-react";

interface ProjectDetailProps {
  project: {
    id: string;
    title: string;
    description: string | null;
    type: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    generatedContent: Array<{
      id: string;
      title: string;
      content: string;
      contentType: string;
      createdAt: Date;
      generationData: any;
    }>;
    user: {
      name: string | null;
      email: string;
    };
  };
}

export default function ProjectDetailClient({ project }: ProjectDetailProps) {
  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'SOCIAL_POST': return <Target className="w-4 h-4" />;
      case 'BLOG_POST': return <FileText className="w-4 h-4" />;
      case 'EMAIL': return <FileText className="w-4 h-4" />;
      case 'AD_COPY': return <Zap className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      'PUBLISHED': 'bg-green-500/20 text-green-400 border-green-500/30',
      'IN_PROGRESS': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      'DRAFT': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
      'COMPLETED': 'bg-purple-500/20 text-purple-400 border-purple-500/30'
    };
    
    return statusColors[status as keyof typeof statusColors] || statusColors.DRAFT;
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText(text);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800/30 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link href="/projects">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Projects
              </Button>
            </Link>
            <div className="w-px h-6 bg-slate-600" />
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-gradient-to-r from-purple-600/20 to-blue-600/20">
                {getContentTypeIcon(project.type)}
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-white">{project.title}</h1>
                <div className="flex items-center space-x-3 mt-1">
                  <div className={`px-3 py-1 rounded-full text-sm border ${getStatusBadge(project.status)}`}>
                    {project.status.toLowerCase().replace('_', ' ')}
                  </div>
                  <span className="text-slate-400 text-sm">
                    {project.generatedContent.length} content pieces
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Link href={`/create?project=${project.id}`}>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Content
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Project Info Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <FileText className="w-5 h-5 mr-2 text-purple-400" />
                  Project Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-slate-500 mb-1">Description</p>
                  <p className="text-slate-300">
                    {project.description || 'No description provided'}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-slate-500 mb-1">Content Type</p>
                  <div className="flex items-center space-x-2">
                    {getContentTypeIcon(project.type)}
                    <span className="text-slate-300">
                      {project.type.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-slate-500 mb-1">Created By</p>
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-300">{project.user.name || project.user.email}</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-slate-500 mb-1">Created</p>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-300">{formatDate(project.createdAt)}</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-slate-500 mb-1">Last Updated</p>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-300">{formatDate(project.updatedAt)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Content List */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Generated Content</CardTitle>
                    <CardDescription className="text-slate-400">
                      All content created for this project
                    </CardDescription>
                  </div>
                  <Link href={`/create?project=${project.id}`}>
                    <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-800">
                      <Plus className="w-4 h-4 mr-2" />
                      Create More
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {project.generatedContent.length > 0 ? (
                  <div className="space-y-6">
                    {project.generatedContent.map((content) => (
                      <div key={content.id} className="border border-slate-700 rounded-lg p-6 bg-slate-800/30">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-1">{content.title}</h3>
                            <div className="flex items-center space-x-3 text-sm text-slate-400">
                              <div className="flex items-center space-x-1">
                                {getContentTypeIcon(content.contentType)}
                                <span>{content.contentType.replace('_', ' ')}</span>
                              </div>
                              <span>•</span>
                              <span>{formatDate(content.createdAt)}</span>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard(content.content)}
                              className="text-slate-400 hover:text-white"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-slate-400 hover:text-white"
                            >
                              <Share className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="bg-slate-700/30 rounded-lg p-4">
                          <div className="prose prose-invert max-w-none">
                            <div className="whitespace-pre-wrap text-slate-200 leading-relaxed">
                              {content.content.length > 500 
                                ? `${content.content.substring(0, 500)}...` 
                                : content.content
                              }
                            </div>
                          </div>
                        </div>

                        {content.content.length > 500 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="mt-2 text-purple-400 hover:text-purple-300"
                          >
                            Show Full Content
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <FileText className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                    <h3 className="text-xl font-semibold text-white mb-2">No content yet</h3>
                    <p className="text-slate-400 max-w-md mx-auto mb-6">
                      Start creating AI-powered content for this project
                    </p>
                    <Link href={`/create?project=${project.id}`}>
                      <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Create First Content
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

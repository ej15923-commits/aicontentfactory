
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import ProjectDetailClient from "./project-detail-client";

export const dynamic = "force-dynamic";

interface ProjectDetailPageProps {
  params: { id: string };
}

export default async function ProjectDetailPage({ params }: ProjectDetailPageProps) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect("/auth/signin");
  }

  // Fetch project with content
  const project = await prisma.contentProject.findFirst({
    where: { 
      id: params.id,
      userId: session.user.id // Ensure user owns this project
    },
    include: { 
      generatedContent: {
        orderBy: { createdAt: 'desc' }
      },
      user: {
        select: { name: true, email: true }
      }
    }
  });

  if (!project) {
    redirect("/projects");
  }

  return <ProjectDetailClient project={project} />;
}


import { WorkflowsClient } from './workflows-client';

export default function WorkflowsPage() {
  return <WorkflowsClient />;
}

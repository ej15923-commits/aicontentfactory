
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import CreateContentClient from "./create-content-client";

export const dynamic = "force-dynamic";

export default async function CreatePage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect("/auth/signin");
  }

  // Fetch templates and user projects
  const [templates, projects] = await Promise.all([
    prisma.template.findMany({
      where: { isPublic: true },
      orderBy: { name: 'asc' }
    }),
    prisma.contentProject.findMany({
      where: { userId: session.user.id },
      select: { id: true, title: true, type: true },
      orderBy: { updatedAt: 'desc' },
      take: 10
    })
  ]);

  return (
    <CreateContentClient 
      userId={session.user.id}
      templates={templates || []}
      projects={projects || []}
    />
  );
}


import { PrismaClient } from '@prisma/client';

// Define ContentType enum locally since it's not exported
enum ContentType {
  TEXT = 'TEXT',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
  SOCIAL_POST = 'SOCIAL_POST',
  EMAIL = 'EMAIL',
  BLOG_POST = 'BLOG_POST',
  AD_COPY = 'AD_COPY'
}
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Create admin test user
  const hashedPassword = await bcrypt.hash('johndoe123', 12);
  
  const adminUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      companyName: 'Admin Corp',
      password: hashedPassword,
    },
  });

  // Create sample templates
  const templates = [
    {
      name: 'Social Media Post',
      description: 'Engaging social media content for various platforms',
      category: 'Social Media',
      contentType: ContentType.SOCIAL_POST,
      prompt: 'Create an engaging social media post about {topic} for {platform}. Keep it {tone} and include relevant hashtags. Target audience: {audience}.',
      variables: { topic: 'string', platform: 'string', tone: 'string', audience: 'string' },
    },
    {
      name: 'Blog Post Outline',
      description: 'Comprehensive blog post structure and outline',
      category: 'Content Marketing',
      contentType: ContentType.BLOG_POST,
      prompt: 'Create a detailed blog post outline for "{title}". Include introduction, main sections with subpoints, and conclusion. Target SEO keywords: {keywords}.',
      variables: { title: 'string', keywords: 'string' },
    },
    {
      name: 'Email Campaign',
      description: 'Professional email marketing content',
      category: 'Email Marketing',
      contentType: ContentType.EMAIL,
      prompt: 'Write a compelling email for {campaign_type} campaign. Subject: {subject}. Include clear call-to-action and personalized content for {audience}.',
      variables: { campaign_type: 'string', subject: 'string', audience: 'string' },
    },
    {
      name: 'Ad Copy',
      description: 'High-converting advertisement copy',
      category: 'Advertising',
      contentType: ContentType.AD_COPY,
      prompt: 'Create persuasive ad copy for {product} targeting {target_audience}. Focus on {key_benefit} and include a strong call-to-action. Keep it under {word_limit} words.',
      variables: { product: 'string', target_audience: 'string', key_benefit: 'string', word_limit: 'number' },
    },
    {
      name: 'Video Script',
      description: 'Engaging video content script',
      category: 'Video Content',
      contentType: ContentType.VIDEO,
      prompt: 'Write a {duration}-minute video script about {topic}. Include hook, main content, and call-to-action. Style: {style}. Target audience: {audience}.',
      variables: { duration: 'number', topic: 'string', style: 'string', audience: 'string' },
    }
  ];

  for (const template of templates) {
    const existingTemplate = await prisma.template.findFirst({
      where: { name: template.name },
    });
    
    if (!existingTemplate) {
      await prisma.template.create({
        data: template,
      });
    }
  }

  // Create sample content project
  const project = await prisma.contentProject.create({
    data: {
      title: 'Welcome Campaign',
      description: 'Sample project to demonstrate content generation',
      type: ContentType.SOCIAL_POST,
      userId: adminUser.id,
    },
  });

  console.log('Database seeded successfully!');
  console.log(`Admin user: ${adminUser.email}`);
  console.log(`Sample project: ${project.title}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
